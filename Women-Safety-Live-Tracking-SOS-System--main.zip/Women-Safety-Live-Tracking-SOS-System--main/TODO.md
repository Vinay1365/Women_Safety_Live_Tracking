# TODO

- [x] Inspect backend DB connection code
- [x] Create `backend/.env` with `PORT` and `MONGODB_URI`
- [x] Update `backend/.env` with new Atlas URI (cluster0.ajftf7z)
- [ ] Verify backend starts and connects to MongoDB (current: DNS SRV lookup failing: ECONNREFUSED)

