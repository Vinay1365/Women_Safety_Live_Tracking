import { Camera, Cloud, FileAudio, FileVideo, KeyRound, Mic, Upload } from "lucide-react";
import { useRef, useState } from "react";
import api from "../services/api";
import VoiceSentimentMonitor from "./VoiceSentimentMonitor";

export default function MediaRecorderPanel({ emergencyId }) {
  const [recording, setRecording] = useState(null);
  const [access, setAccess] = useState({ audio: false, video: false });
  const [evidenceSessionId, setEvidenceSessionId] = useState(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [lockerProvider, setLockerProvider] = useState("ready");
  const [securedCount, setSecuredCount] = useState(0);
  const [uploading, setUploading] = useState(false);
  const [currentStream, setCurrentStream] = useState(null);
  const recorderRef = useRef(null);
  const chunkCountRef = useRef(0);

  const targetEmergencyId = emergencyId || evidenceSessionId;

  function accessLabel() {
    if (access.audio && access.video) return "Mic & Camera Allowed";
    if (access.audio) return "Mic Allowed";
    if (access.video) return "Camera Allowed";
    return "Allow Mic & Camera";
  }

  function permissionErrorText(type, err) {
    if (err?.name === "NotAllowedError") {
      return `${type === "video" ? "Camera and microphone" : "Microphone"} access was blocked. Allow permission from the browser address bar and try again.`;
    }
    if (err?.name === "NotFoundError") {
      return `${type === "video" ? "Camera or microphone" : "Microphone"} device was not found on this system.`;
    }
    return `Unable to access ${type === "video" ? "camera/microphone" : "microphone"}. Please check browser permissions.`;
  }

  async function ensureEvidenceSession() {
    if (targetEmergencyId) return targetEmergencyId;
    const { data } = await api.post("/emergencies/evidence-session");
    setEvidenceSessionId(data.emergency._id);
    return data.emergency._id;
  }

  async function requestAccess(type, keepStream = false) {
    setError("");
    setMessage("");

    if (!navigator.mediaDevices?.getUserMedia) {
      setError("Your browser does not support audio/video recording permissions.");
      return null;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: type === "video"
      });

      setAccess((current) => ({
        audio: true,
        video: current.video || type === "video"
      }));
      setMessage(`${type === "video" ? "Camera and microphone" : "Microphone"} access granted.`);

      if (!keepStream) {
        stream.getTracks().forEach((track) => track.stop());
        return null;
      }

      return stream;
    } catch (err) {
      setError(permissionErrorText(type, err));
      return null;
    }
  }

  async function uploadEvidence(file, silent = false) {
    if (!file) return;
    setError("");
    if (!silent) setMessage("");

    if (!file.type.startsWith("audio/") && !file.type.startsWith("video/")) {
      setError("Please select an audio or video file.");
      return;
    }

    try {
      setUploading(true);
      const sessionId = await ensureEvidenceSession();
      const formData = new FormData();
      formData.append("media", file);
      const { data } = await api.post(`/emergencies/${sessionId}/media`, formData);
      setLockerProvider(data.locker?.provider || data.media?.cloudProvider || "locker");
      setSecuredCount((count) => count + 1);
      if (!silent) {
        setMessage(`${file.type.startsWith("audio/") ? "Audio" : "Video"} uploaded to the evidence locker.`);
      }
    } catch (err) {
      setError(err.response?.data?.message || "Evidence upload failed. Try again when your connection is stable.");
    } finally {
      setUploading(false);
    }
  }

  async function start(type) {
    const stream = await requestAccess(type, true);
    if (!stream) return;
    const sessionId = await ensureEvidenceSession();

    chunkCountRef.current = 0;
    const recorder = new MediaRecorder(stream);
    recorder.ondataavailable = async (event) => {
      if (!event.data?.size) return;
      chunkCountRef.current += 1;
      const blob = new Blob([event.data], { type: type === "video" ? "video/webm" : "audio/webm" });
      await uploadEvidence(blob, true);
      setMessage(`${type} evidence chunk ${chunkCountRef.current} secured in the locker.`);
    };
    recorder.onstop = async () => {
      setMessage(`${type} recording stopped. ${chunkCountRef.current} evidence ${chunkCountRef.current === 1 ? "chunk is" : "chunks are"} safe.`);
      stream.getTracks().forEach((track) => track.stop());
      setCurrentStream(null);
    };
    recorder.start(10_000);
    recorderRef.current = recorder;
    setRecording(type);
    setLockerProvider("uploading");
    setCurrentStream(stream);
    setMessage(`${type} recording started. Evidence uploads automatically every 10 seconds.`);
  }

  function stop() {
    recorderRef.current?.stop();
    setRecording(null);
  }

  return (
    <div className="glass-panel rounded-lg p-4">
      <div className="flex items-center justify-between gap-3">
        <h3 className="flex items-center gap-2 font-black">
          <Cloud size={18} /> Evidence Locker
        </h3>
        <span className={`rounded-full px-2.5 py-1 text-xs font-bold ${targetEmergencyId ? "bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-200" : "bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-300"}`}>
          {uploading ? "Uploading" : emergencyId ? "SOS Active" : targetEmergencyId ? "Evidence Session" : "Ready"}
        </span>
      </div>
      <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Audio/video is uploaded to secure locker storage while recording, so evidence remains available even if the phone is damaged.</p>

      <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
        <div className="rounded-lg bg-slate-100 p-3 dark:bg-slate-800">
          <p className="text-xs text-slate-500 dark:text-slate-400">Locker</p>
          <p className="font-black capitalize">{lockerProvider}</p>
        </div>
        <div className="rounded-lg bg-slate-100 p-3 dark:bg-slate-800">
          <p className="text-xs text-slate-500 dark:text-slate-400">Secured files</p>
          <p className="font-black">{securedCount}</p>
        </div>
      </div>

      <button
        type="button"
        onClick={() => requestAccess("video")}
        className="mt-4 flex w-full items-center justify-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-3 text-sm font-black text-emerald-800 shadow-sm transition hover:-translate-y-0.5 dark:border-emerald-900 dark:bg-emerald-950/40 dark:text-emerald-100"
      >
        <KeyRound size={17} /> {accessLabel()}
      </button>

      <div className="mt-3 grid grid-cols-3 gap-2">
        <button disabled={recording || !access.audio} onClick={() => start("audio")} className="rounded-lg bg-white px-3 py-3 text-sm font-bold shadow-sm transition hover:-translate-y-0.5 disabled:opacity-50 dark:bg-slate-800">
          <Mic className="mx-auto mb-1" size={18} /> Record Audio
        </button>
        <button disabled={recording || !access.video} onClick={() => start("video")} className="rounded-lg bg-white px-3 py-3 text-sm font-bold shadow-sm transition hover:-translate-y-0.5 disabled:opacity-50 dark:bg-slate-800">
          <Camera className="mx-auto mb-1" size={18} /> Record Video
        </button>
        <button disabled={!recording} onClick={stop} className="rounded-lg bg-rose-600 px-3 py-3 text-sm font-bold text-white shadow-lg shadow-rose-900/15 transition hover:-translate-y-0.5 disabled:opacity-50">
          <Upload className="mx-auto mb-1" size={18} /> Stop
        </button>
      </div>

      <div className="mt-3 grid grid-cols-2 gap-2">
        <label className="flex cursor-pointer items-center justify-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-3 text-sm font-bold shadow-sm transition hover:-translate-y-0.5 dark:border-slate-700 dark:bg-slate-800">
          <FileAudio size={17} /> Upload Audio
          <input type="file" accept="audio/*" className="hidden" onChange={(event) => uploadEvidence(event.target.files?.[0])} />
        </label>
        <label className="flex cursor-pointer items-center justify-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-3 text-sm font-bold shadow-sm transition hover:-translate-y-0.5 dark:border-slate-700 dark:bg-slate-800">
          <FileVideo size={17} /> Upload Video
          <input type="file" accept="video/*" className="hidden" onChange={(event) => uploadEvidence(event.target.files?.[0])} />
        </label>
      </div>

      {/* Voice Sentiment Monitor - Show when recording audio */}
      {recording === "audio" && currentStream && (
        <div className="mt-4">
          <VoiceSentimentMonitor 
            stream={currentStream} 
            emergencyId={targetEmergencyId}
            onPanicDetected={(data) => {
              setMessage(`⚠️ Panic detected! Emergency contacts notified automatically.`);
            }}
          />
        </div>
      )}

      {message && <p className="mt-3 text-sm font-semibold text-emerald-600">{message}</p>}
      {error && <p className="mt-3 rounded-lg bg-rose-50 p-3 text-sm font-semibold text-rose-700 dark:bg-rose-950/60 dark:text-rose-200">{error}</p>}
    </div>
  );
}
