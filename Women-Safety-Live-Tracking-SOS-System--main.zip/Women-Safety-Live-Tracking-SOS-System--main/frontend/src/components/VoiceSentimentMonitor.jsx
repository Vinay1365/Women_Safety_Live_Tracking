import { useState, useEffect, useRef } from "react";
import { AlertTriangle, Volume2, Activity } from "lucide-react";
import VoiceAnalyzer from "../utils/voiceAnalyzer";
import api from "../services/api";

export default function VoiceSentimentMonitor({ stream, emergencyId, onPanicDetected }) {
  const [analysis, setAnalysis] = useState(null);
  const [panicAlerted, setPanicAlerted] = useState(false);
  const analyzerRef = useRef(null);
  const animationRef = useRef(null);

  useEffect(() => {
    if (!stream) return;

    const initializeAnalyzer = async () => {
      const analyzer = new VoiceAnalyzer();
      await analyzer.initialize(stream);
      analyzerRef.current = analyzer;
      startAnalysis();
    };

    initializeAnalyzer();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      if (analyzerRef.current) {
        analyzerRef.current.stop();
      }
    };
  }, [stream]);

  const startAnalysis = () => {
    const analyze = () => {
      if (!analyzerRef.current) return;

      const result = analyzerRef.current.analyze();
      if (result) {
        setAnalysis(result);

        // Trigger panic alert if detected and not already alerted
        if (result.panicDetected && !panicAlerted) {
          handlePanicDetection(result);
        }
      }

      animationRef.current = requestAnimationFrame(analyze);
    };

    analyze();
  };

  const handlePanicDetection = async (result) => {
    setPanicAlerted(true);
    
    // Alert the user
    onPanicDetected?.({
      stressLevel: result.stressLevel,
      panicDetected: true,
      timestamp: new Date().toISOString()
    });

    // Auto-alert emergency contacts
    try {
      await api.post(`/emergencies/${emergencyId}/panic-alert`, {
        voiceStressLevel: result.stressLevel,
        detectionTime: new Date().toISOString(),
        reason: "Voice stress analysis detected panic in caller"
      });
    } catch (err) {
      console.error("Failed to send panic alert:", err);
    }
  };

  if (!analysis) {
    return null;
  }

  const getStressColor = (level) => {
    if (level < 0.3) return "from-emerald-500 to-cyan-500";
    if (level < 0.6) return "from-amber-500 to-orange-500";
    return "from-rose-600 to-red-600";
  };

  const getStressLabel = (level) => {
    if (level < 0.3) return "Normal";
    if (level < 0.6) return "Moderate Stress";
    if (level < 0.8) return "High Stress";
    return "Critical - PANIC DETECTED";
  };

  return (
    <div className="rounded-lg border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-800">
      <div className="flex items-center gap-2 mb-3">
        <Activity size={18} className="text-rose-600" />
        <h4 className="font-semibold text-slate-900 dark:text-white">Voice Sentiment Analysis</h4>
      </div>

      {/* Stress Level Visualization */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-semibold text-slate-700 dark:text-slate-300">
            {getStressLabel(analysis.stressLevel)}
          </span>
          <span className="text-sm font-bold text-slate-600 dark:text-slate-400">
            {(analysis.stressLevel * 100).toFixed(0)}%
          </span>
        </div>
        
        {/* Progress Bar */}
        <div className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
          <div
            className={`h-full bg-gradient-to-r ${getStressColor(analysis.stressLevel)} transition-all duration-300`}
            style={{ width: `${analysis.stressLevel * 100}%` }}
          ></div>
        </div>
      </div>

      {/* Panic Alert */}
      {analysis.panicDetected && (
        <div className="mb-4 rounded-lg bg-red-50 border border-red-200 p-3 dark:bg-red-950/30 dark:border-red-900/50 flex items-start gap-3">
          <AlertTriangle size={16} className="text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-red-900 dark:text-red-200 text-sm">🚨 PANIC DETECTED</p>
            <p className="text-xs text-red-800 dark:text-red-300 mt-1">
              Extreme stress levels detected. Emergency contacts are being notified automatically.
            </p>
          </div>
        </div>
      )}

      {/* Detailed Metrics */}
      <div className="grid grid-cols-2 gap-2 text-xs">
        <div className="rounded bg-slate-50 dark:bg-slate-900 p-2">
          <p className="text-slate-500 dark:text-slate-400">Frequency</p>
          <p className="font-bold text-slate-900 dark:text-white">
            {analysis.dominantFrequency.toFixed(0)} Hz
          </p>
        </div>
        <div className="rounded bg-slate-50 dark:bg-slate-900 p-2">
          <p className="text-slate-500 dark:text-slate-400">Energy</p>
          <p className="font-bold text-slate-900 dark:text-white">
            {analysis.energy.toFixed(0)}
          </p>
        </div>
        <div className="rounded bg-slate-50 dark:bg-slate-900 p-2">
          <p className="text-slate-500 dark:text-slate-400">High Freq</p>
          <p className="font-bold text-slate-900 dark:text-white">
            {(analysis.highFreqRatio * 100).toFixed(0)}%
          </p>
        </div>
        <div className="rounded bg-slate-50 dark:bg-slate-900 p-2">
          <p className="text-slate-500 dark:text-slate-400">Low Freq</p>
          <p className="font-bold text-slate-900 dark:text-white">
            {(analysis.lowFreqRatio * 100).toFixed(0)}%
          </p>
        </div>
      </div>

      {/* Info Message */}
      <p className="text-xs text-slate-500 dark:text-slate-400 mt-3 text-center">
        <Volume2 className="inline mr-1" size={12} />
        Real-time voice analysis active
      </p>
    </div>
  );
}
