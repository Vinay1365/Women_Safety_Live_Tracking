import { NavLink, Outlet } from "react-router-dom";
import { Bell, History, Home, LogOut, Moon, Phone, ShieldCheck, Siren, Sun, UserRound, BarChart3 } from "lucide-react";
import { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";

const baseNavItems = [
  { to: "/", label: "Dashboard", icon: Home },
  { to: "/contacts", label: "Contacts", icon: Phone },
  { to: "/history", label: "History", icon: History },
  { to: "/analytics", label: "Analytics", icon: BarChart3 },
  { to: "/profile", label: "Profile", icon: UserRound }
];

export default function Shell() {
  const { logout, user } = useAuth();
  const [dark, setDark] = useState(localStorage.getItem("safety_theme") === "dark");
  const navItems = user?.role === "police"
    ? [...baseNavItems, { to: "/police", label: "Police", icon: Siren }]
    : baseNavItems;

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    localStorage.setItem("safety_theme", dark ? "dark" : "light");
  }, [dark]);

  return (
    <div className="min-h-screen text-slate-900 dark:text-slate-100">
      <aside className={`fixed bottom-0 z-20 grid w-full border-t border-white/70 bg-white/90 p-2 shadow-[0_-14px_40px_rgba(15,23,42,0.08)] backdrop-blur-xl dark:border-slate-800/80 dark:bg-slate-950/88 md:left-0 md:top-0 md:h-screen md:w-72 md:grid-cols-1 md:content-start md:gap-2 md:border-r md:border-t-0 md:p-5 md:shadow-none ${user?.role === "police" ? "grid-cols-6" : "grid-cols-5"}`}>
        <div className="mb-6 hidden md:block">
          <div className="flex items-center gap-3 rounded-lg bg-slate-950 p-3 text-white shadow-soft dark:bg-white dark:text-slate-950">
            <span className="grid h-11 w-11 place-items-center rounded-lg bg-rose-600 text-white shadow-lg shadow-rose-900/20">
              <ShieldCheck size={22} />
            </span>
            <div>
              <p className="font-bold">Sakhi Shield</p>
              <p className="text-xs text-slate-300 dark:text-slate-600">Live safety network</p>
            </div>
          </div>
          <div className="mt-4 rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-900 dark:border-emerald-900/70 dark:bg-emerald-950/40 dark:text-emerald-100">
            <div className="flex items-center gap-2 font-bold">
              <Bell size={16} /> Protection mode
            </div>
            <p className="mt-1 text-xs opacity-80">Contacts, tracking, and recording tools are ready.</p>
          </div>
        </div>
        {navItems.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              `flex items-center justify-center gap-2 rounded-lg px-3 py-3 text-sm font-semibold transition md:justify-start ${
                isActive
                  ? "bg-rose-600 text-white shadow-lg shadow-rose-900/15"
                  : "text-slate-600 hover:bg-white hover:text-slate-950 dark:text-slate-300 dark:hover:bg-slate-900 dark:hover:text-white"
              }`
            }
          >
            <Icon size={18} />
            <span className="hidden sm:inline">{label}</span>
          </NavLink>
        ))}
      </aside>

      <main className="pb-24 md:ml-72 md:pb-0">
        <header className="sticky top-0 z-10 flex items-center justify-between border-b border-white/70 bg-white/75 px-4 py-4 backdrop-blur-xl dark:border-slate-800/80 dark:bg-slate-950/72 md:px-8">
          <div>
            <p className="text-sm text-slate-500 dark:text-slate-400">Welcome back</p>
            <h1 className="text-xl font-black">{user?.name}</h1>
          </div>
          <div className="flex items-center gap-2">
            <button className="rounded-lg border border-slate-200 bg-white p-2 shadow-sm transition hover:-translate-y-0.5 dark:border-slate-700 dark:bg-slate-900" onClick={() => setDark((value) => !value)} aria-label="Toggle theme">
              {dark ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            <button className="rounded-lg border border-slate-200 bg-white p-2 text-slate-600 shadow-sm transition hover:-translate-y-0.5 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300" onClick={logout} aria-label="Logout">
              <LogOut size={18} />
            </button>
          </div>
        </header>
        <Outlet />
      </main>
    </div>
  );
}
