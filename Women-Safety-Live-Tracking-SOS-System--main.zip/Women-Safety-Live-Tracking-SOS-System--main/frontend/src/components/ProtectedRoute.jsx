import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();

  if (loading) return <div className="grid min-h-screen place-items-center text-slate-600">Loading safety workspace...</div>;
  if (!user) return <Navigate to="/login" replace />;
  return children;
}
