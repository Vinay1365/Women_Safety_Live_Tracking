import { Mic, PhoneCall, ShieldAlert, Square } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { useEmergency } from "../context/EmergencyContext";

const FAKE_CALL_SECONDS = 10;
const DOUBLE_PRESS_MS = 600;
const SHAKE_THRESHOLD = 20;
const SHAKE_COOLDOWN_MS = 8000;
const CONTACT_CACHE_KEY = "safety_contacts_cache";
const OFFLINE_QUEUE_KEY = "safety_offline_sos_queue";

function getCachedContacts() {
  try {
    const cached = localStorage.getItem(CONTACT_CACHE_KEY);
    return cached ? JSON.parse(cached) : [];
  } catch {
    return [];
  }
}

function persistOfflineAlert(alert) {
  try {
    const cached = localStorage.getItem(OFFLINE_QUEUE_KEY);
    const queue = cached ? JSON.parse(cached) : [];
    queue.push(alert);
    localStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(queue.slice(-25)));
  } catch {
    // Ignore storage failures and continue with the SMS draft.
  }
}

function getSmsBody(location, trigger) {
  const coordinates = location ? `${location.lat}, ${location.lng}` : "Location unavailable";
  const mapsUrl = location ? `https://maps.google.com/?q=${location.lat},${location.lng}` : "No map link available";
  return `SOS alert (${trigger}). My GPS coordinates: ${coordinates}. Map: ${mapsUrl}`;
}

function buildSmsUrl(phones, body) {
  const recipients = phones.join(",");
  return `sms:${recipients}?body=${encodeURIComponent(body)}`;
}

function getCurrentPosition() {
  return new Promise((resolve, reject) => {
    navigator.geolocation.getCurrentPosition(resolve, reject, {
      enableHighAccuracy: true,
      timeout: 12000,
      maximumAge: 0
    });
  });
}

function normalizePosition(position) {
  return {
    lat: position.coords.latitude,
    lng: position.coords.longitude,
    accuracy: position.coords.accuracy,
    speed: position.coords.speed,
    heading: position.coords.heading,
    timestamp: new Date().toISOString()
  };
}

export default function SOSButton({ onEmergencyStarted }) {
  const { status, activeEmergency, startEmergency, endEmergency } = useEmergency();
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [fakeCallState, setFakeCallState] = useState({
    ringing: false,
    secondsLeft: FAKE_CALL_SECONDS
  });

  const recognitionRef = useRef(null);
  const fakeCallTimerRef = useRef(null);
  const lastFakePressAtRef = useRef(0);

  function clearFakeCallTimer() {
    if (fakeCallTimerRef.current) {
      clearInterval(fakeCallTimerRef.current);
      fakeCallTimerRef.current = null;
    }
  }

  async function triggerOfflineSos(trigger = "button") {
    const contacts = getCachedContacts().filter((contact) => contact.phone);
    let location = null;

    try {
      const position = await getCurrentPosition();
      location = normalizePosition(position);
    } catch {
      location = null;
    }

    const body = getSmsBody(location, trigger);
    persistOfflineAlert({
      triggerType: trigger,
      location,
      body,
      createdAt: new Date().toISOString()
    });

    if (!contacts.length) {
      window.alert("Offline SOS saved locally, but no cached contacts are available yet. Open Contacts while online to save trusted numbers.");
      return null;
    }

    const phones = contacts.map((contact) => contact.phone).filter(Boolean);
    const smsUrl = buildSmsUrl(phones, body);
    window.location.href = smsUrl;
    return null;
  }

  async function handleSos(trigger = "button") {
    clearFakeCallTimer();

    if (typeof navigator !== "undefined" && navigator.onLine === false) {
      await triggerOfflineSos(trigger);
      return;
    }

    try {
      const emergency = await startEmergency(trigger);
      onEmergencyStarted?.(emergency);
    } catch (error) {
      console.error("SOS activation failed, switching to offline mode:", error);
      await triggerOfflineSos(trigger);
    }
  }

  function startFakeCallCountdown() {
    clearFakeCallTimer();
    setFakeCallState({ ringing: true, secondsLeft: FAKE_CALL_SECONDS });

    let remaining = FAKE_CALL_SECONDS;
    fakeCallTimerRef.current = setInterval(() => {
      remaining -= 1;

      if (remaining <= 0) {
        clearFakeCallTimer();
        setFakeCallState({ ringing: false, secondsLeft: FAKE_CALL_SECONDS });
        handleSos("fake-call");
        return;
      }

      setFakeCallState({ ringing: true, secondsLeft: remaining });
    }, 1000);
  }

  async function handleFakeCall() {
    const now = Date.now();
    const isDoublePress = now - lastFakePressAtRef.current <= DOUBLE_PRESS_MS;
    lastFakePressAtRef.current = now;

    if (isDoublePress) {
      handleSos("wearable");
      return;
    }

    if (fakeCallState.ringing || status === "starting") return;
    startFakeCallCountdown();
  }

  useEffect(() => {
    if (!voiceEnabled || activeEmergency) return;

    const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Recognition) return;

    const recognition = new Recognition();
    recognitionRef.current = recognition;

    recognition.continuous = true;
    recognition.lang = "en-US";
    recognition.onresult = (event) => {
      const text = event.results[event.results.length - 1][0].transcript.toLowerCase();
      const triggers = ["help me", "emergency", "save me", "help", "sos"];
      if (triggers.some((trigger) => text.includes(trigger))) handleSos("voice");
    };

    recognition.start();

    return () => {
      recognition.stop();
      recognitionRef.current = null;
    };
  }, [voiceEnabled, activeEmergency]);

  useEffect(() => {
    if (activeEmergency) {
      clearFakeCallTimer();
      setFakeCallState({ ringing: false, secondsLeft: FAKE_CALL_SECONDS });
    }

    return () => clearFakeCallTimer();
  }, [activeEmergency]);

  useEffect(() => {
    if (activeEmergency || !window.DeviceMotionEvent) return;

    // Require 3 shakes within a short window before triggering SOS.
    const SHAKES_REQUIRED = 3;
    const SHAKE_WINDOW_MS = 4000;

    // More robust shake counting:
    // - Count shakes only when there is a strong peak above threshold.
    // - Add a short per-peak debounce to avoid rapid repeated counts on one shake.
    const PEAK_DEBOUNCE_MS = 650;

    let shakeCount = 0;
    let firstShakeAt = 0;
    let lastTriggerAt = 0;
    let lastPeakAt = 0;

    function resetShakeSequenceIfNeeded(now) {
      if (shakeCount === 0) {
        firstShakeAt = now;
        return;
      }

      if (now - firstShakeAt > SHAKE_WINDOW_MS) {
        shakeCount = 0;
        firstShakeAt = now;
      }
    }

    function onMotion(event) {
      const acc = event.accelerationIncludingGravity;
      if (!acc) return;

      const x = acc.x ?? 0;
      const y = acc.y ?? 0;
      const z = acc.z ?? 0;

      const magnitude = Math.sqrt(x * x + y * y + z * z);
      const now = Date.now();

      if (magnitude <= SHAKE_THRESHOLD) return;
      if (now - lastTriggerAt <= SHAKE_COOLDOWN_MS) return;

      // Debounce peaks so one physical shake doesn't create multiple counts.
      if (now - lastPeakAt <= PEAK_DEBOUNCE_MS) return;
      lastPeakAt = now;

      resetShakeSequenceIfNeeded(now);

      // Count distinct shake events.
      if (shakeCount === 0) firstShakeAt = now;
      shakeCount += 1;

      if (shakeCount >= SHAKES_REQUIRED) {
        shakeCount = 0;
        lastTriggerAt = now;
        handleSos("shake");
      }
    }

    // Use capture to improve delivery in background/other listeners.
    window.addEventListener("devicemotion", onMotion, { passive: true, capture: true });

    return () => window.removeEventListener("devicemotion", onMotion, { capture: true });
  }, [activeEmergency]);



  if (activeEmergency) {
    return (
      <button
        onClick={endEmergency}
        className="flex w-full items-center justify-center gap-2 rounded-lg bg-slate-950 px-5 py-4 text-lg font-black text-white shadow-soft transition hover:-translate-y-0.5 dark:bg-white dark:text-slate-950"
      >
        <Square size={20} /> End Emergency
      </button>
    );
  }

  return (
    <div className="grid gap-3">
      <button
        onClick={() => handleSos("button")}
        disabled={status === "starting"}
        className="sos-pulse relative min-h-44 overflow-hidden rounded-lg bg-gradient-to-br from-rose-500 via-rose-600 to-red-700 px-6 py-8 text-5xl font-black text-white shadow-[0_24px_70px_rgba(225,29,72,0.35)] transition hover:-translate-y-1 hover:shadow-[0_28px_80px_rgba(225,29,72,0.45)] disabled:opacity-70"
      >
        <span className="absolute inset-x-0 top-0 h-20 bg-white/15" />
        <ShieldAlert className="mx-auto mb-3" size={34} />
        {status === "starting" ? "STARTING..." : "SOS"}
        <span className="mt-2 block text-sm font-bold tracking-normal text-rose-50">Tap for instant emergency alert</span>
      </button>

      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={() => setVoiceEnabled((value) => !value)}
          className={`flex items-center justify-center gap-2 rounded-lg border px-4 py-3 text-sm font-bold transition hover:-translate-y-0.5 ${
            voiceEnabled
              ? "border-emerald-300 bg-emerald-50 text-emerald-800 dark:border-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-100"
              : "border-slate-200 bg-white/60 dark:border-slate-700 dark:bg-slate-900/60"
          }`}
        >
          <Mic size={17} /> {voiceEnabled ? "Voice On" : "Voice SOS"}
        </button>

        <button
          onClick={handleFakeCall}
          disabled={fakeCallState.ringing || status === "starting"}
          className={`flex items-center justify-center gap-2 rounded-lg border border-slate-200 bg-white/60 px-4 py-3 text-sm font-bold transition hover:-translate-y-0.5 disabled:opacity-70 dark:border-slate-700 dark:bg-slate-900/60 ${
            fakeCallState.ringing ? "cursor-wait" : ""
          }`}
        >
          <PhoneCall size={17} />
          {fakeCallState.ringing ? `Ringing... ${fakeCallState.secondsLeft}s` : "Fake Call"}
        </button>
      </div>
    </div>
  );
}
