import { useRef, useEffect, useState } from "react";
import { QRCodeSVG } from "qrcode.react";
import { Download, QrCode } from "lucide-react";

export default function QRSafetyCard({ user, contacts = [] }) {
  const qrRef = useRef();
  const [qrValue, setQrValue] = useState("");

  // Generate QR code data from user and contacts info
  useEffect(() => {
    const safetyData = {
      name: user?.name || "Unknown",
      phone: user?.phone || "",
      bloodGroup: user?.bloodGroup || "Not specified",
      allergies: user?.allergies || "None",
      emergencyDiseases: user?.emergencyDiseases || "None",
      medicalHistory: user?.medicalHistory || "None",
      emergencyContacts: contacts.slice(0, 5).map(contact => ({
        name: contact.name,
        relationship: contact.relationship,
        phone: contact.phone,
        email: contact.email
      }))
    };

    // Create a formatted string for the QR code
    setQrValue(JSON.stringify(safetyData));
  }, [user, contacts]);

  const downloadQRCode = () => {
    const svg = qrRef.current?.querySelector("svg");
    if (svg) {
      const svgData = new XMLSerializer().serializeToString(svg);
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");
      const img = new Image();
      
      img.onload = () => {
        canvas.width = img.width;
        canvas.height = img.height;
        ctx.drawImage(img, 0, 0);
        
        const link = document.createElement("a");
        link.href = canvas.toDataURL("image/png");
        link.download = `${user?.name || "safety"}-qr-card.png`;
        link.click();
      };
      
      img.src = "data:image/svg+xml;base64," + btoa(svgData);
    }
  };

  return (
    <div className="glass-panel rounded-lg p-5">
      <div className="flex items-center gap-3">
        <span className="grid h-11 w-11 place-items-center rounded-lg bg-blue-600 text-white">
          <QrCode size={20} />
        </span>
        <div>
          <h3 className="text-xl font-black">Safety QR Card</h3>
          <p className="text-sm text-slate-500 dark:text-slate-400">Scan with police or hospital for instant info</p>
        </div>
      </div>

      <div className="mt-6 flex flex-col items-center gap-4">
        {/* QR Code Display */}
        <div ref={qrRef} className="rounded-lg border-4 border-blue-100 bg-white p-4 dark:border-blue-900/50 dark:bg-slate-950">
          {qrValue && (
            <QRCodeSVG
              value={qrValue}
              size={256}
              level="H"
              includeMargin={true}
            />
          )}
        </div>

        {/* QR Code Info Card */}
        <div className="w-full rounded-lg bg-blue-50 p-4 dark:bg-blue-950/30">
          <p className="text-sm font-bold text-blue-900 dark:text-blue-100">Contains:</p>
          <ul className="mt-2 space-y-1 text-sm text-blue-800 dark:text-blue-200">
            <li>✓ Name: <span className="font-semibold">{user?.name || "Not set"}</span></li>
            <li>✓ Phone: <span className="font-semibold">{user?.phone || "Not set"}</span></li>
            <li>✓ Blood Group: <span className="font-semibold">{user?.bloodGroup || "Not set"}</span></li>
            <li>✓ Allergies: <span className="font-semibold">{user?.allergies || "None"}</span></li>
            <li>✓ Emergency Diseases: <span className="font-semibold">{user?.emergencyDiseases || "None"}</span></li>
            <li>✓ {contacts.length} Emergency Contacts</li>
          </ul>
        </div>

        {/* Download Button */}
        <button
          onClick={downloadQRCode}
          className="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-6 py-3 font-bold text-white shadow-lg shadow-blue-900/15 transition hover:-translate-y-0.5"
        >
          <Download size={18} /> Download QR Card
        </button>

        {/* Instructions */}
        <div className="w-full rounded-lg border border-blue-200 bg-blue-50 p-4 text-sm text-blue-900 dark:border-blue-900 dark:bg-blue-950/40 dark:text-blue-100">
          <p className="font-semibold">How to use:</p>
          <ul className="mt-2 space-y-1">
            <li>• Print and carry this card, or show it on your phone</li>
            <li>• Police and hospitals can scan it instantly</li>
            <li>• Contains your vital health and emergency contact info</li>
            <li>• Update your profile to refresh the QR code</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
