import { MapPin, Radio, ShieldCheck } from "lucide-react";

export default function AuthLayout({ title, subtitle, children }) {
  return (
    <div className="grid min-h-screen bg-slate-950 text-white lg:grid-cols-[1.08fr_0.92fr]">
      <section className="relative hidden overflow-hidden bg-[url('https://images.unsplash.com/photo-1573164713988-8665fc963095?auto=format&fit=crop&w=1600&q=85')] bg-cover bg-center lg:block">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-950/90 via-slate-950/55 to-rose-950/50" />
        <div className="relative flex h-full flex-col justify-between p-12">
          <div className="flex items-center gap-3 text-lg font-black">
            <span className="grid h-11 w-11 place-items-center rounded-lg bg-rose-600 shadow-lg shadow-rose-950/40">
              <ShieldCheck />
            </span>
            Sakhi Shield
          </div>
          <div className="max-w-xl">
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-2 text-sm font-semibold backdrop-blur">
              <Radio size={16} /> Real-time response platform
            </div>
            <h1 className="text-5xl font-black leading-tight">Fast help, live location, safer decisions.</h1>
            <p className="mt-5 text-lg text-slate-200">Trigger SOS, notify trusted contacts, record evidence, and keep location updates moving until you are safe.</p>
            <div className="mt-8 grid grid-cols-3 gap-3">
              {["SOS alerts", "GPS trail", "Evidence vault"].map((item) => (
                <div key={item} className="rounded-lg border border-white/15 bg-white/10 p-3 text-sm font-bold backdrop-blur">
                  {item}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
      <section className="flex items-center justify-center bg-[radial-gradient(circle_at_top,rgba(244,63,94,0.24),transparent_28rem)] px-5 py-10">
        <div className="glass-panel w-full max-w-md rounded-lg p-6 text-slate-950 dark:text-white md:p-8">
          <div className="mb-8 flex items-center gap-3 lg:hidden">
            <ShieldCheck className="text-rose-600" />
            <span className="font-black">Sakhi Shield</span>
          </div>
          <h2 className="text-3xl font-bold">{title}</h2>
          <p className="mt-2 text-slate-500 dark:text-slate-300">{subtitle}</p>
          <div className="mt-5 flex items-center gap-2 rounded-lg bg-emerald-50 px-3 py-2 text-sm font-semibold text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-100">
            <MapPin size={16} /> Live tracking ready after sign in
          </div>
          <div className="mt-8">{children}</div>
        </div>
      </section>
    </div>
  );
}
