import { CircleF, GoogleMap, MarkerF, PolylineF, useLoadScript } from "@react-google-maps/api";
import { ExternalLink } from "lucide-react";

const defaultCenter = { lat: 28.6139, lng: 77.209 };
const mapsApiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || "";
const hasValidMapsKey = mapsApiKey && mapsApiKey !== "replace_with_google_maps_key";

const heatmapStyles = {
  safe: { color: "#16a34a", label: "Safe Areas" },
  moderate: { color: "#f59e0b", label: "Moderate Risk Areas" },
  high: { color: "#dc2626", label: "High Risk Areas" }
};

function HeatmapLegend({ areas = [] }) {
  if (!areas.length) return null;

  return (
    <div className="absolute right-3 top-3 max-w-xs rounded-lg bg-white/92 p-3 text-xs text-slate-700 shadow-soft backdrop-blur dark:bg-slate-950/88 dark:text-slate-100">
      <p className="mb-2 text-sm font-black">Emergency Heatmap</p>
      {Object.entries(heatmapStyles).map(([level, style]) => (
        <div key={level} className="mt-1 flex items-center gap-2">
          <span className="h-3 w-3 rounded-full" style={{ backgroundColor: style.color }} />
          <span>{style.label}</span>
        </div>
      ))}
      <p className="mt-2 opacity-75">{areas.length} historical zones shown</p>
    </div>
  );
}

export default function LiveMap({ location, route = [], places = [], heatmapAreas = [] }) {
  const { isLoaded } = useLoadScript({
    googleMapsApiKey: hasValidMapsKey ? mapsApiKey : ""
  });

  const center = location || defaultCenter;
  const path = route.length ? route : location ? [location] : [];
  const googleMapsUrl = `https://www.google.com/maps?q=${center.lat},${center.lng}&z=${location ? 16 : 12}`;

  if (!hasValidMapsKey) {
    return (
      <div className="relative min-h-[360px] overflow-hidden rounded-lg md:min-h-[520px]">
        <iframe
          title="Google Maps emergency location"
          src={`https://maps.google.com/maps?q=${center.lat},${center.lng}&z=${location ? 16 : 12}&output=embed`}
          className="h-[360px] w-full border-0 md:h-[520px]"
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
        />
        <div className="absolute left-3 top-3 max-w-xs rounded-lg bg-white/92 p-3 text-sm text-slate-700 shadow-soft backdrop-blur dark:bg-slate-950/88 dark:text-slate-100">
          <p className="font-black">Google Maps preview</p>
          <p className="mt-1 text-xs opacity-75">Add a real Maps API key for live markers and route drawing.</p>
        </div>
        <a
          href={googleMapsUrl}
          target="_blank"
          rel="noreferrer"
          className="absolute bottom-3 right-3 inline-flex items-center gap-2 rounded-lg bg-rose-600 px-3 py-2 text-sm font-bold text-white shadow-lg shadow-rose-950/20"
        >
          Open Maps <ExternalLink size={15} />
        </a>
        {places.length > 0 && (
          <div className="absolute bottom-3 left-3 hidden max-w-xs rounded-lg bg-white/92 p-3 text-xs text-slate-700 shadow-soft backdrop-blur dark:bg-slate-950/88 dark:text-slate-100 md:block">
            Nearby: {places.map((place) => place.name).join(", ")}
          </div>
        )}
        <HeatmapLegend areas={heatmapAreas} />
      </div>
    );
  }

  if (!isLoaded) return <div className="grid min-h-[360px] place-items-center rounded-lg bg-slate-100 dark:bg-slate-900">Loading map...</div>;

  return (
    <div className="relative">
      <GoogleMap mapContainerClassName="h-[360px] md:h-[520px] w-full rounded-lg" center={center} zoom={location ? 16 : 12}>
      {heatmapAreas.map((area) => {
        const style = heatmapStyles[area.riskLevel] || heatmapStyles.safe;
        return (
          <CircleF
            key={`${area.center.lat}-${area.center.lng}-${area.riskLevel}`}
            center={area.center}
            radius={area.radiusMeters || 600}
            options={{
              fillColor: style.color,
              fillOpacity: area.riskLevel === "high" ? 0.28 : 0.2,
              strokeColor: style.color,
              strokeOpacity: 0.8,
              strokeWeight: 2
            }}
          />
        );
      })}
      {location && <MarkerF position={location} label="You" />}
      {places.map((place) => (
        <MarkerF key={place.name} position={place.location} label={place.type[0]} />
      ))}
      {path.length > 1 && <PolylineF path={path} options={{ strokeColor: "#e11d48", strokeWeight: 4 }} />}
      </GoogleMap>
      <HeatmapLegend areas={heatmapAreas} />
    </div>
  );
}
