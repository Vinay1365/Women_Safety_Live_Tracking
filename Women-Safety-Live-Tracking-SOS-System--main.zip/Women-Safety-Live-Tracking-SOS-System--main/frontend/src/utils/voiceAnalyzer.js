/**
 * Voice Sentiment Analysis - Analyzes audio stress levels based on pitch and frequency patterns
 */

class VoiceAnalyzer {
  constructor() {
    this.audioContext = null;
    this.analyser = null;
    this.stream = null;
    this.sourceNode = null;
    this.dataArray = null;
    this.bufferLength = 0;
  }

  async initialize(stream) {
    this.stream = stream;
    this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
    this.analyser = this.audioContext.createAnalyser();
    this.analyser.fftSize = 2048;
    
    this.bufferLength = this.analyser.frequencyBinCount;
    this.dataArray = new Uint8Array(this.bufferLength);
    
    this.sourceNode = this.audioContext.createMediaStreamSource(stream);
    this.sourceNode.connect(this.analyser);
  }

  /**
   * Analyzes voice to detect stress level
   * Returns: { stressLevel: 0-1, panicDetected: boolean, frequency: number, amplitude: number }
   */
  analyze() {
    if (!this.analyser) return null;
    
    this.analyser.getByteFrequencyData(this.dataArray);
    
    // Calculate dominant frequency
    const dominantFreq = this.getDominantFrequency();
    
    // Calculate energy (amplitude)
    const energy = this.calculateEnergy();
    
    // Analyze frequency distribution for stress patterns
    const { highFreqRatio, lowFreqRatio } = this.analyzeFrequencyBands();
    
    // Calculate stress level (0-1)
    // Higher pitch + higher energy + more high-frequency content = more stress
    const stressLevel = this.calculateStressLevel(dominantFreq, energy, highFreqRatio);
    
    // Panic detection: very high stress + rapid energy spikes
    const panicDetected = stressLevel > 0.8 && energy > 150;
    
    return {
      stressLevel: Math.min(stressLevel, 1),
      panicDetected,
      dominantFrequency: dominantFreq,
      energy,
      highFreqRatio,
      lowFreqRatio
    };
  }

  getDominantFrequency() {
    let maxValue = 0;
    let maxIndex = 0;
    
    for (let i = 0; i < this.bufferLength; i++) {
      if (this.dataArray[i] > maxValue) {
        maxValue = this.dataArray[i];
        maxIndex = i;
      }
    }
    
    // Convert bin index to Hz
    const nyquist = this.audioContext.sampleRate / 2;
    return (maxIndex * nyquist) / this.bufferLength;
  }

  calculateEnergy() {
    let sum = 0;
    for (let i = 0; i < this.bufferLength; i++) {
      sum += this.dataArray[i] * this.dataArray[i];
    }
    return Math.sqrt(sum / this.bufferLength);
  }

  analyzeFrequencyBands() {
    // Split frequency data into bands
    const lowBand = this.dataArray.slice(0, Math.floor(this.bufferLength * 0.2));
    const midBand = this.dataArray.slice(Math.floor(this.bufferLength * 0.2), Math.floor(this.bufferLength * 0.6));
    const highBand = this.dataArray.slice(Math.floor(this.bufferLength * 0.6), this.bufferLength);
    
    const lowEnergy = lowBand.reduce((a, b) => a + b, 0) / lowBand.length;
    const midEnergy = midBand.reduce((a, b) => a + b, 0) / midBand.length;
    const highEnergy = highBand.reduce((a, b) => a + b, 0) / highBand.length;
    
    const totalEnergy = lowEnergy + midEnergy + highEnergy;
    
    return {
      highFreqRatio: highEnergy / totalEnergy || 0,
      lowFreqRatio: lowEnergy / totalEnergy || 0
    };
  }

  calculateStressLevel(frequency, energy, highFreqRatio) {
    // Stress indicators:
    // - Higher pitch (frequency > 200Hz indicates stress)
    // - Higher energy (louder volume)
    // - More high-frequency content (tension in voice)
    
    const freqScore = Math.min(frequency / 500, 1); // Normalize to 0-1
    const energyScore = Math.min(energy / 200, 1);  // Normalize to 0-1
    const freqContentScore = Math.min(highFreqRatio * 2, 1);
    
    // Weighted average
    return (freqScore * 0.3 + energyScore * 0.4 + freqContentScore * 0.3);
  }

  stop() {
    if (this.sourceNode) {
      this.sourceNode.disconnect();
    }
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
    }
    if (this.audioContext) {
      this.audioContext.close();
    }
  }
}

export default VoiceAnalyzer;
