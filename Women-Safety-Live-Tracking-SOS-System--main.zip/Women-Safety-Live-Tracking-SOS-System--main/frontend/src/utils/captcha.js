export function createCaptchaChallenge() {
  const puzzles = [
    { question: "Select the tiger image", options: ["🍎", "🐯", "🚗"], answer: "🐯" },
    { question: "Pick the red square", options: ["🟥", "🟦", "🟩"], answer: "🟥" },
    { question: "Choose the lock icon", options: ["🔒", "🔑", "🔓"], answer: "🔒" },
    { question: "Select the owl image", options: ["🦉", "🐶", "🐱"], answer: "🦉" },
    { question: "Choose the book icon", options: ["📖", "🎁", "🍔"], answer: "📖" }
  ];

  const puzzle = puzzles[Math.floor(Math.random() * puzzles.length)];
  return { ...puzzle, selected: "" };
}
