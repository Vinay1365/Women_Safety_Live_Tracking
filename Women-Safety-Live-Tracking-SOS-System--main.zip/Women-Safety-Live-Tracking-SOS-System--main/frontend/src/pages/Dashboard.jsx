import { useCallback, useEffect, useMemo, useState } from "react";
import api from "../services/api";
import LiveMap from "../components/LiveMap";
import MediaRecorderPanel from "../components/MediaRecorderPanel";
import SOSButton from "../components/SOSButton";
import { useEmergency } from "../context/EmergencyContext";
import { Activity, Bot, Calculator, Clock, FileText, Flag, MapPin, Navigation, Radio, ShieldAlert, Route, Users, BellRing } from "lucide-react";

function formatTime(value) {
  if (!value) return "Just now";
  return new Date(value).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}

function formatDateTime(value) {
  if (!value) return "Not set";
  return new Date(value).toLocaleString([], { hour: "numeric", minute: "2-digit", month: "short", day: "numeric" });
}

function normalizePosition(position) {
  return {
    lat: position.coords.latitude,
    lng: position.coords.longitude,
    accuracy: position.coords.accuracy,
    speed: position.coords.speed,
    heading: position.coords.heading,
    timestamp: new Date().toISOString()
  };
}

function getTripPosition() {
  return new Promise((resolve, reject) => {
    navigator.geolocation.getCurrentPosition(
      (position) => resolve(normalizePosition(position)),
      reject,
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 }
    );
  });
}

export default function Dashboard() {
  const { activeEmergency, currentLocation, status } = useEmergency();
  const [places, setPlaces] = useState([]);
  const [chat, setChat] = useState("");
  const [reply, setReply] = useState("");
  const [safetyScore, setSafetyScore] = useState(null);
  const [dangerLevel, setDangerLevel] = useState("Unknown");
  const [safetyData, setSafetyData] = useState(null);
  const [isCalculatingSafety, setIsCalculatingSafety] = useState(false);
  const [heatmapAreas, setHeatmapAreas] = useState([]);
  const [heatmapSummary, setHeatmapSummary] = useState(null);
  const [activeTrip, setActiveTrip] = useState(null);
  const [destination, setDestination] = useState("");
  const [expectedMinutes, setExpectedMinutes] = useState(30);
  const [tripError, setTripError] = useState("");

  useEffect(() => {
    if (!currentLocation) return;
    api
      .get(`/nearby/places?lat=${currentLocation.lat}&lng=${currentLocation.lng}`)
      .then(({ data }) => setPlaces(data.places))
      .catch(() => setPlaces([]));

    api
      .get(`/safety/heatmap?lat=${currentLocation.lat}&lng=${currentLocation.lng}`)
      .then(({ data }) => {
        setHeatmapAreas(data.areas || []);
        setHeatmapSummary(data.summary || null);
      })
      .catch(() => {
        setHeatmapAreas([]);
        setHeatmapSummary(null);
      });
  }, [currentLocation]);

  const calculateSafetyScore = useCallback(() => {
    if (!currentLocation) return;

    setIsCalculatingSafety(true);
    api
      .get(`/safety/score?lat=${currentLocation.lat}&lng=${currentLocation.lng}`)
      .then(({ data }) => {
        setSafetyScore(data.safetyScore);
        setDangerLevel(data.dangerLevel);
        setSafetyData(data);
      })
      .catch(() => {
        setSafetyScore(null);
        setDangerLevel("Unknown");
        setSafetyData(null);
      })
      .finally(() => {
        setIsCalculatingSafety(false);
      });
  }, [currentLocation]);

  useEffect(() => {
    calculateSafetyScore();
  }, [calculateSafetyScore]);

  useEffect(() => {
    api
      .get("/trips/active")
      .then(({ data }) => setActiveTrip(data.trip))
      .catch(() => setActiveTrip(null));
  }, []);

  const safetyFactors = useMemo(() => {
    const details = safetyData?.details || {};
    return [
      { label: "Time", value: details.timeRisk, icon: Clock },
      { label: "Location", value: details.locationRisk, icon: MapPin },
      { label: "Crime data", value: details.crimeRisk, icon: Activity },
      { label: "User reports", value: details.reportRisk, icon: FileText }
    ];
  }, [safetyData]);

  const routeHistory = useMemo(() => activeEmergency?.route || [], [activeEmergency]);
  const recentRoutePoints = routeHistory.slice(-5).reverse();

  async function askAssistant(event) {
    event.preventDefault();
    if (!chat.trim()) return;
    const { data } = await api.post("/chatbot", { message: chat });
    setReply(data.reply);
  }

  async function startTrip(event) {
    event.preventDefault();
    setTripError("");

    if (!destination.trim()) {
      setTripError("Enter a destination before starting trip monitoring.");
      return;
    }

    try {
      const location = currentLocation || await getTripPosition();
      const { data } = await api.post("/trips/start", {
        destination,
        expectedMinutes,
        location
      });

      setActiveTrip(data.trip);
      setDestination("");
      setExpectedMinutes(30);
    } catch (error) {
      setTripError(error.response?.data?.message || "Could not start trip monitoring. Check GPS access and try again.");
    }
  }

  async function completeTrip() {
    if (!activeTrip) return;
    try {
      const location = currentLocation || await getTripPosition();
      const { data } = await api.patch(`/trips/${activeTrip._id}/complete`, { location });
      setActiveTrip(data.trip);
    } catch (error) {
      setTripError(error.response?.data?.message || "Could not mark trip as reached.");
    }
  }

  async function cancelTrip() {
    if (!activeTrip) return;
    try {
      const { data } = await api.patch(`/trips/${activeTrip._id}/cancel`);
      setActiveTrip(data.trip);
    } catch (error) {
      setTripError(error.response?.data?.message || "Could not cancel trip monitoring.");
    }
  }

  return (
    <div className="grid gap-6 p-4 md:p-8">
      <section className="grid gap-4 lg:grid-cols-[1.4fr_0.8fr_0.8fr_0.8fr]">
        <div className="glass-panel rounded-lg p-5">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="text-sm font-bold uppercase text-rose-600 dark:text-rose-300">Family live tracking dashboard</p>
              <h2 className="mt-1 text-3xl font-black tracking-normal md:text-4xl">Guardian can monitor every SOS update.</h2>
              <p className="mt-2 max-w-2xl text-sm text-slate-500 dark:text-slate-400">Real-time location tracking, route history, and emergency notifications stay visible in one place.</p>
            </div>
            <span className={`rounded-full px-4 py-2 text-sm font-black capitalize ${status === "active" ? "bg-rose-600 text-white" : "bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-100"}`}>
              {status}
            </span>
          </div>

          <div className="mt-5 grid gap-3 sm:grid-cols-3">
            <div className="rounded-lg border border-white/70 bg-white/80 p-4 shadow-soft dark:border-slate-800 dark:bg-slate-900/76">
              <Users className="mb-2 text-rose-600" />
              <p className="text-sm text-slate-500 dark:text-slate-400">Live tracking</p>
              <p className="text-xl font-black">{activeEmergency ? "On" : "Idle"}</p>
            </div>
            <div className="rounded-lg border border-white/70 bg-white/80 p-4 shadow-soft dark:border-slate-800 dark:bg-slate-900/76">
              <Route className="mb-2 text-emerald-600" />
              <p className="text-sm text-slate-500 dark:text-slate-400">Route points</p>
              <p className="text-xl font-black">{routeHistory.length}</p>
            </div>
            <div className="rounded-lg border border-white/70 bg-white/80 p-4 shadow-soft dark:border-slate-800 dark:bg-slate-900/76">
              <BellRing className="mb-2 text-amber-500" />
              <p className="text-sm text-slate-500 dark:text-slate-400">Notifications</p>
              <p className="text-xl font-black">{activeEmergency ? "Sent" : "Waiting"}</p>
            </div>
          </div>
        </div>

        <div className="rounded-lg border border-white/70 bg-white/80 p-5 shadow-soft dark:border-slate-800 dark:bg-slate-900/76">
          <Radio className="mb-3 text-rose-600" />
          <p className="text-sm text-slate-500 dark:text-slate-400">Tracking</p>
          <p className="text-2xl font-black">{activeEmergency ? "Live" : "Ready"}</p>
        </div>

        <div className="rounded-lg border border-white/70 bg-white/80 p-5 shadow-soft dark:border-slate-800 dark:bg-slate-900/76">
          <Navigation className="mb-3 text-emerald-600" />
          <p className="text-sm text-slate-500 dark:text-slate-400">GPS accuracy</p>
          <p className="text-2xl font-black">{currentLocation?.accuracy ? `${Math.round(currentLocation.accuracy)} m` : "Waiting"}</p>
        </div>

        <div className="rounded-lg border border-white/70 bg-white/80 p-5 shadow-soft dark:border-slate-800 dark:bg-slate-900/76">
          <ShieldAlert className={`mb-3 ${dangerLevel === "Low" ? "text-emerald-600" : dangerLevel === "Medium" ? "text-amber-500" : "text-rose-600"}`} />
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-sm text-slate-500 dark:text-slate-400">Safety Score System</p>
              <p className="text-2xl font-black">{safetyData?.output || (safetyScore !== null ? `Safety Score = ${safetyScore}/100` : "Pending")}</p>
            </div>
            <button
              type="button"
              onClick={calculateSafetyScore}
              disabled={!currentLocation || isCalculatingSafety}
              className="rounded-lg bg-slate-950 p-2 text-white shadow-sm transition hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-50 dark:bg-white dark:text-slate-950"
              title="Calculate safety score"
              aria-label="Calculate safety score"
            >
              <Calculator size={18} />
              <span className="sr-only">Calculate</span>
            </button>
          </div>
          <p className="mt-2 uppercase text-sm font-black text-slate-500 dark:text-slate-400">Danger Level = {dangerLevel}</p>
          {safetyData?.message && <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">{safetyData.message}</p>}
          <div className="mt-4 rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm dark:border-slate-700 dark:bg-slate-950/45">
            <div className="flex items-center justify-between gap-3">
              <span className="font-black">Calculate</span>
              <button
                type="button"
                onClick={calculateSafetyScore}
                disabled={!currentLocation || isCalculatingSafety}
                className="rounded-lg bg-rose-600 px-3 py-2 text-xs font-black uppercase text-white shadow-sm transition hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {isCalculatingSafety ? "Calculating" : "Run"}
              </button>
            </div>
            <p className="mt-2 text-slate-500 dark:text-slate-400">
              Based on time, location, crime data, and recent user reports.
            </p>
          </div>
          <div className="mt-4 grid gap-2">
            {safetyFactors.map(({ label, value, icon: Icon }) => (
              <div key={label} className="flex items-center justify-between rounded-md bg-slate-100 px-3 py-2 text-sm dark:bg-slate-800">
                <span className="flex items-center gap-2 font-bold">
                  <Icon size={15} /> {label}
                </span>
                <span className="text-slate-500 dark:text-slate-400">{value ?? "--"} risk</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="grid gap-6 xl:grid-cols-[390px_1fr]">
        <section className="grid content-start gap-4">
          <div className="glass-panel rounded-lg p-5">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-500 dark:text-slate-400">Emergency status</p>
                <h2 className="text-2xl font-black capitalize">{status}</h2>
              </div>
              <ShieldAlert className={status === "active" ? "text-rose-600" : "text-emerald-500"} />
            </div>
            <SOSButton />
          </div>

          <div className="glass-panel rounded-lg p-5">
            <h3 className="flex items-center gap-2 font-black">
              <BellRing size={18} /> Emergency notifications
            </h3>
            <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
              {activeEmergency ? "Guardian alerts are being sent and the live route is updating automatically." : "Activate SOS to notify trusted contacts and begin live tracking."}
            </p>
          </div>

          <div className="glass-panel rounded-lg p-5">
            <h3 className="flex items-center gap-2 font-black">
              <Flag size={18} /> Trip Monitoring
            </h3>
            {activeTrip?.status === "active" || activeTrip?.status === "overdue" ? (
              <div className="mt-3 rounded-lg bg-slate-100 p-3 text-sm dark:bg-slate-800">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-black">{activeTrip.destination}</p>
                    <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                      Expected by {formatDateTime(activeTrip.expectedArrivalAt)}
                    </p>
                  </div>
                  <span className={`rounded-full px-2 py-1 text-xs font-black uppercase ${activeTrip.status === "overdue" ? "bg-rose-600 text-white" : "bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-100"}`}>
                    {activeTrip.status}
                  </span>
                </div>
                <p className="mt-3 text-slate-500 dark:text-slate-400">
                  If this destination is not reached on time, family contacts are notified automatically.
                </p>
                <div className="mt-3 grid grid-cols-2 gap-2">
                  <button type="button" onClick={completeTrip} className="rounded-lg bg-emerald-600 px-3 py-2 text-sm font-black text-white shadow-sm transition hover:-translate-y-0.5">
                    Reached
                  </button>
                  <button type="button" onClick={cancelTrip} className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-black shadow-sm transition hover:-translate-y-0.5 dark:border-slate-700 dark:bg-slate-900">
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={startTrip} className="mt-3 grid gap-3">
                <input
                  className="soft-input rounded-lg px-3 py-2"
                  placeholder="Destination"
                  value={destination}
                  onChange={(event) => setDestination(event.target.value)}
                />
                <label className="grid gap-1 text-sm font-bold">
                  Expected time
                  <select
                    className="soft-input rounded-lg px-3 py-2 font-normal"
                    value={expectedMinutes}
                    onChange={(event) => setExpectedMinutes(Number(event.target.value))}
                  >
                    <option value={15}>15 minutes</option>
                    <option value={30}>30 minutes</option>
                    <option value={45}>45 minutes</option>
                    <option value={60}>1 hour</option>
                    <option value={90}>1.5 hours</option>
                    <option value={120}>2 hours</option>
                  </select>
                </label>
                <button
                  type="submit"
                  className="rounded-lg bg-slate-950 px-4 py-2 font-black text-white shadow-sm transition hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-50 dark:bg-white dark:text-slate-950"
                >
                  Start journey
                </button>
                {tripError && <p className="text-sm font-bold text-rose-600 dark:text-rose-300">{tripError}</p>}
              </form>
            )}
          </div>

          <MediaRecorderPanel emergencyId={activeEmergency?._id} />

          <div className="glass-panel rounded-lg p-4">
            <h3 className="flex items-center gap-2 font-black"><Bot size={18} /> Emergency Assistant</h3>
            <form onSubmit={askAssistant} className="mt-3 flex gap-2">
              <input className="soft-input min-w-0 flex-1 rounded-lg px-3 py-2" placeholder="What should I do?" value={chat} onChange={(e) => setChat(e.target.value)} />
              <button className="rounded-lg bg-slate-950 px-4 py-2 font-bold text-white shadow-sm transition hover:-translate-y-0.5 dark:bg-white dark:text-slate-950">Ask</button>
            </form>
            {reply && <p className="mt-3 rounded-lg bg-slate-100 p-3 text-sm dark:bg-slate-800">{reply}</p>}
          </div>
        </section>

        <section className="grid gap-4">
          <div className="glass-panel overflow-hidden rounded-lg p-3">
            <LiveMap location={currentLocation} route={routeHistory} places={places} heatmapAreas={heatmapAreas} />
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="rounded-lg border border-white/70 bg-white/80 p-4 shadow-soft dark:border-slate-800 dark:bg-slate-900/75">
              <h3 className="flex items-center gap-2 font-black"><Route size={18} /> Route history</h3>
              <div className="mt-3 space-y-2">
                {recentRoutePoints.length ? recentRoutePoints.map((point, index) => (
                  <div key={`${point.timestamp}-${index}`} className="rounded-lg bg-slate-100 px-3 py-2 text-sm dark:bg-slate-800">
                    <div className="flex items-center justify-between gap-3">
                      <span className="font-bold">Point {routeHistory.length - index}</span>
                      <span className="text-xs text-slate-500 dark:text-slate-400">{formatTime(point.timestamp)}</span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {Math.round(point.lat * 10000) / 10000}, {Math.round(point.lng * 10000) / 10000}
                    </p>
                  </div>
                )) : (
                  <p className="text-sm text-slate-500 dark:text-slate-400">No route data yet. Start SOS to begin tracking.</p>
                )}
              </div>
            </div>

            <div className="rounded-lg border border-white/70 bg-white/80 p-4 shadow-soft dark:border-slate-800 dark:bg-slate-900/75">
              <h3 className="flex items-center gap-2 font-black"><MapPin size={18} /> Current location</h3>
              <div className="mt-3 rounded-lg bg-slate-100 p-3 text-sm dark:bg-slate-800">
                {currentLocation ? (
                  <>
                    <p className="font-bold">{Math.round(currentLocation.lat * 10000) / 10000}, {Math.round(currentLocation.lng * 10000) / 10000}</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Updated {formatTime(currentLocation.timestamp)}</p>
                  </>
                ) : (
                  <p className="text-slate-500 dark:text-slate-400">Waiting for live location...</p>
                )}
              </div>
            </div>
          </div>

          <div className="grid gap-3 md:grid-cols-3">
            {heatmapSummary && (
              <div className="rounded-lg border border-white/70 bg-white/80 p-4 shadow-soft dark:border-slate-800 dark:bg-slate-900/75 md:col-span-3">
                <h3 className="font-black">Emergency Heatmap</h3>
                <div className="mt-3 grid gap-2 text-sm sm:grid-cols-3">
                  <div className="rounded-lg bg-emerald-50 p-3 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-100">
                    <p className="font-black">Safe Areas</p>
                    <p>{heatmapSummary.safe} zones</p>
                  </div>
                  <div className="rounded-lg bg-amber-50 p-3 text-amber-800 dark:bg-amber-950/40 dark:text-amber-100">
                    <p className="font-black">Moderate Risk Areas</p>
                    <p>{heatmapSummary.moderate} zones</p>
                  </div>
                  <div className="rounded-lg bg-rose-50 p-3 text-rose-800 dark:bg-rose-950/40 dark:text-rose-100">
                    <p className="font-black">High Risk Areas</p>
                    <p>{heatmapSummary.high} zones</p>
                  </div>
                </div>
                <p className="mt-2 text-xs text-slate-500 dark:text-slate-400">
                  Based on {heatmapSummary.incidentsAnalyzed} historical incidents from the last {heatmapSummary.windowDays} days.
                </p>
              </div>
            )}
            {places.map((place) => (
              <div key={place.name} className="rounded-lg border border-white/70 bg-white/80 p-4 shadow-soft transition hover:-translate-y-1 dark:border-slate-800 dark:bg-slate-900/75">
                <MapPin className="mb-2 text-rose-600" size={18} />
                <p className="font-black">{place.name}</p>
                <p className="text-sm text-slate-500 dark:text-slate-400">{place.type} - {place.distance}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
