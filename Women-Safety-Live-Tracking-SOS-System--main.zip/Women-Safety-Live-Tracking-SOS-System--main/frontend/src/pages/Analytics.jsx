import { useEffect, useState } from "react";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import api from "../services/api";
import { Activity, AlertTriangle, CheckCircle, TrendingUp, MapPin, Clock } from "lucide-react";

export default function Analytics() {
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    loadAnalytics();
  }, []);

  async function loadAnalytics() {
    try {
      setLoading(true);
      const { data } = await api.get("/analytics");
      setAnalytics(data);
    } catch (err) {
      setError(err.response?.data?.message || "Failed to load analytics");
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-rose-600 mx-auto mb-4"></div>
          <p className="text-slate-600 dark:text-slate-300">Loading analytics...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 md:p-8">
        <div className="glass-panel rounded-lg p-6 text-center text-rose-600 dark:text-rose-400">
          <AlertTriangle className="mx-auto mb-2" size={32} />
          <p>{error}</p>
        </div>
      </div>
    );
  }

  const COLORS = ["#f43f5e", "#06b6d4", "#10b981", "#f59e0b", "#8b5cf6"];

  return (
    <div className="p-4 md:p-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <Activity size={32} className="text-rose-600" />
          <h1 className="text-3xl font-black">Safety Analytics</h1>
        </div>
        <p className="text-slate-600 dark:text-slate-400">Track your safety journey and emergency patterns</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {/* Total Alerts */}
        <div className="glass-panel rounded-lg p-5">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm font-semibold text-slate-600 dark:text-slate-400">Total SOS Alerts</p>
              <p className="text-3xl font-black text-rose-600 mt-2">{analytics?.totalAlerts || 0}</p>
            </div>
            <span className="grid h-11 w-11 place-items-center rounded-lg bg-rose-50 dark:bg-rose-950/30">
              <AlertTriangle size={20} className="text-rose-600" />
            </span>
          </div>
        </div>

        {/* Active Alerts */}
        <div className="glass-panel rounded-lg p-5">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm font-semibold text-slate-600 dark:text-slate-400">Active Emergencies</p>
              <p className="text-3xl font-black text-amber-600 mt-2">{analytics?.activeAlerts || 0}</p>
            </div>
            <span className="grid h-11 w-11 place-items-center rounded-lg bg-amber-50 dark:bg-amber-950/30">
              <TrendingUp size={20} className="text-amber-600" />
            </span>
          </div>
        </div>

        {/* Safe Routes */}
        <div className="glass-panel rounded-lg p-5">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm font-semibold text-slate-600 dark:text-slate-400">Safe Routes</p>
              <p className="text-3xl font-black text-emerald-600 mt-2">{analytics?.safeRoutes || 0}</p>
            </div>
            <span className="grid h-11 w-11 place-items-center rounded-lg bg-emerald-50 dark:bg-emerald-950/30">
              <CheckCircle size={20} className="text-emerald-600" />
            </span>
          </div>
        </div>

        {/* Contacts Notified */}
        <div className="glass-panel rounded-lg p-5">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm font-semibold text-slate-600 dark:text-slate-400">Contacts Notified</p>
              <p className="text-3xl font-black text-cyan-600 mt-2">{analytics?.totalContactsNotified || 0}</p>
            </div>
            <span className="grid h-11 w-11 place-items-center rounded-lg bg-cyan-50 dark:bg-cyan-950/30">
              <Clock size={20} className="text-cyan-600" />
            </span>
          </div>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Monthly Statistics */}
        <div className="glass-panel rounded-lg p-6">
          <h3 className="text-xl font-black mb-4">Monthly SOS Alerts (Last 12 Months)</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={analytics?.monthlyStats || []}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="month" stroke="#64748b" />
              <YAxis stroke="#64748b" />
              <Tooltip 
                contentStyle={{ backgroundColor: "#1e293b", border: "1px solid #64748b", borderRadius: "8px" }}
                labelStyle={{ color: "#f1f5f9" }}
              />
              <Line type="monotone" dataKey="alerts" stroke="#f43f5e" strokeWidth={2} dot={{ r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Alert Types */}
        <div className="glass-panel rounded-lg p-6">
          <h3 className="text-xl font-black mb-4">Alerts by Type</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={analytics?.alertsByType || []}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ type, count }) => `${type}: ${count}`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="count"
              >
                {analytics?.alertsByType?.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ backgroundColor: "#1e293b", border: "1px solid #64748b", borderRadius: "8px" }}
                labelStyle={{ color: "#f1f5f9" }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Dangerous Locations */}
      {analytics?.dangerousLocations && analytics.dangerousLocations.length > 0 && (
        <div className="glass-panel rounded-lg p-6 mb-8">
          <div className="flex items-center gap-2 mb-4">
            <MapPin size={24} className="text-rose-600" />
            <h3 className="text-xl font-black">Dangerous Locations Reported</h3>
          </div>
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {analytics.dangerousLocations.map((location, idx) => (
              <div key={idx} className="rounded-lg border border-rose-200 bg-rose-50 p-4 dark:border-rose-900 dark:bg-rose-950/30">
                <p className="text-sm font-semibold text-rose-900 dark:text-rose-100">
                  {location.incidentCount} incident{location.incidentCount !== 1 ? "s" : ""}
                </p>
                <p className="text-xs text-rose-700 dark:text-rose-300 mt-1">
                  📍 {location.lat.toFixed(4)}, {location.lng.toFixed(4)}
                </p>
                <div className="mt-2 flex flex-wrap gap-1">
                  {location.signals.map((signal, i) => (
                    <span key={i} className="inline-block rounded-full bg-rose-200 px-2 py-0.5 text-xs font-semibold text-rose-900 dark:bg-rose-900/50 dark:text-rose-200">
                      {signal}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Statistics Summary */}
      <div className="glass-panel rounded-lg p-6">
        <h3 className="text-xl font-black mb-4">Emergency Statistics</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <p className="text-sm font-semibold text-slate-600 dark:text-slate-400">Status Breakdown</p>
            <div className="mt-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm">Active Emergencies:</span>
                <span className="font-bold text-amber-600">{analytics?.activeAlerts || 0}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Ended Emergencies:</span>
                <span className="font-bold text-emerald-600">{analytics?.endedAlerts || 0}</span>
              </div>
            </div>
          </div>
          <div>
            <p className="text-sm font-semibold text-slate-600 dark:text-slate-400">Response Time</p>
            <div className="mt-4">
              <div className="text-3xl font-black text-cyan-600">
                {analytics?.avgEmergencyDurationMinutes?.toFixed(1) || 0}
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Average duration (minutes)</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
