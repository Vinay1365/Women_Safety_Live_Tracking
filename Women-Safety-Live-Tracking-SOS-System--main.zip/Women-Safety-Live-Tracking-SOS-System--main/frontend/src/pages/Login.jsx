import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import AuthLayout from "../components/AuthLayout";
import { useAuth } from "../context/AuthContext";
import { createCaptchaChallenge } from "../utils/captcha";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const [captcha, setCaptcha] = useState(createCaptchaChallenge());
  const [error, setError] = useState("");

  function refreshCaptcha() {
    setCaptcha(createCaptchaChallenge());
  }

  async function submit(event) {
    event.preventDefault();
    setError("");
    if (!captcha.selected) {
      setError("Please solve the image puzzle before signing in.");
      return;
    }

    try {
      await login({
        ...form,
        captchaQuestion: captcha.question,
        captchaAnswer: captcha.selected
      });
      navigate("/");
    } catch (err) {
      setError(err.response?.data?.message || "Login failed");
      refreshCaptcha();
    }
  }

  return (
    <AuthLayout title="Sign in" subtitle="Open your safety dashboard and emergency network.">
      <form onSubmit={submit} className="grid gap-4">
        <input className="soft-input rounded-lg px-4 py-3" placeholder="Email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
        <input className="soft-input rounded-lg px-4 py-3" placeholder="Password" type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required />
        <div className="grid gap-2 rounded-lg border border-slate-200 bg-slate-50 p-4 text-sm text-slate-700 dark:border-slate-700 dark:bg-slate-900/50 dark:text-slate-200">
          <div className="font-semibold">Image puzzle challenge</div>
          <div>{captcha.question}</div>
          <div className="grid gap-2 sm:grid-cols-3">
            {captcha.options.map((option) => (
              <button
                key={option}
                type="button"
                onClick={() => setCaptcha({ ...captcha, selected: option })}
                className={`rounded-xl border p-4 text-4xl transition ${captcha.selected === option ? "border-rose-600 bg-rose-100 text-rose-900" : "border-slate-300 bg-white text-slate-900 dark:border-slate-700 dark:bg-slate-950/70 dark:text-slate-100"}`}
              >
                {option}
              </button>
            ))}
          </div>
          <button type="button" onClick={refreshCaptcha} className="rounded-lg bg-slate-900 px-4 py-3 text-white transition hover:bg-slate-800">
            Refresh
          </button>
        </div>
        {error && <p className="rounded-lg bg-rose-50 p-3 text-sm font-semibold text-rose-700 dark:bg-rose-950/60 dark:text-rose-200">{error}</p>}
        <button className="rounded-lg bg-rose-600 px-4 py-3 font-bold text-white shadow-lg shadow-rose-900/15 transition hover:-translate-y-0.5">Sign in</button>
      </form>
      <p className="mt-6 text-sm text-slate-500 dark:text-slate-300">
        New here? <Link className="font-bold text-rose-600 dark:text-white" to="/register">Create account</Link>
      </p>
    </AuthLayout>
  );
}
