import { Mail, Phone, Plus, Trash2, UsersRound } from "lucide-react";
import { useEffect, useState } from "react";
import api from "../services/api";

const CONTACT_CACHE_KEY = "safety_contacts_cache";
const emptyForm = { name: "", relationship: "Family", phone: "", email: "", priority: 1 };

function cacheContacts(contacts) {
  try {
    const cacheCopy = contacts.map(({ name, relationship, phone, email }) => ({ name, relationship, phone, email }));
    localStorage.setItem(CONTACT_CACHE_KEY, JSON.stringify(cacheCopy));
  } catch {
    // ignore storage failures
  }
}

function loadCachedContacts() {
  try {
    const cached = localStorage.getItem(CONTACT_CACHE_KEY);
    return cached ? JSON.parse(cached) : [];
  } catch {
    return [];
  }
}

export default function Contacts() {
  const [contacts, setContacts] = useState([]);
  const [form, setForm] = useState(emptyForm);

  async function loadContacts() {
    try {
      const { data } = await api.get("/contacts");
      setContacts(data.contacts);
      cacheContacts(data.contacts);
    } catch (error) {
      setContacts(loadCachedContacts());
    }
  }

  useEffect(() => {
    loadContacts();
  }, []);

  async function submit(event) {
    event.preventDefault();
    await api.post("/contacts", form);
    setForm(emptyForm);
    loadContacts();
  }

  async function remove(id) {
    await api.delete(`/contacts/${id}`);
    loadContacts();
  }

  return (
    <div className="grid gap-6 p-4 md:p-8 lg:grid-cols-[380px_1fr]">
      <form onSubmit={submit} className="glass-panel rounded-lg p-5">
        <div className="flex items-center gap-3">
          <span className="grid h-11 w-11 place-items-center rounded-lg bg-rose-600 text-white">
            <UsersRound size={20} />
          </span>
          <div>
            <h2 className="text-xl font-black">Trusted Contacts</h2>
            <p className="text-sm text-slate-500 dark:text-slate-400">People and services alerted during SOS.</p>
          </div>
        </div>
        <div className="mt-5 grid gap-3">
          <input className="soft-input rounded-lg px-3 py-2" placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
          <select className="soft-input rounded-lg px-3 py-2" value={form.relationship} onChange={(e) => setForm({ ...form, relationship: e.target.value })}>
            {["Family", "Friend", "Police", "Hospital", "Emergency Service", "Other"].map((item) => <option key={item}>{item}</option>)}
          </select>
          <input className="soft-input rounded-lg px-3 py-2" placeholder="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          <input className="soft-input rounded-lg px-3 py-2" placeholder="Email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          <button className="flex items-center justify-center gap-2 rounded-lg bg-rose-600 px-4 py-3 font-bold text-white shadow-lg shadow-rose-900/15 transition hover:-translate-y-0.5">
            <Plus size={18} /> Add Contact
          </button>
        </div>
      </form>

      <section className="grid content-start gap-3">
        <div className="glass-panel rounded-lg p-5">
          <p className="text-sm font-bold uppercase text-rose-600 dark:text-rose-300">Emergency circle</p>
          <h3 className="text-2xl font-black">{contacts.length} saved contacts</h3>
          <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">Contacts are cached locally so your SOS SMS with GPS coordinates can still use trusted numbers when internet is unavailable.</p>
        </div>
        {contacts.map((contact, index) => (
          <article key={contact._id || `${contact.name}-${index}`} className="flex items-center justify-between gap-4 rounded-lg border border-white/70 bg-white/80 p-4 shadow-soft transition hover:-translate-y-1 dark:border-slate-800 dark:bg-slate-900/75">
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="font-black">{contact.name}</h3>
                <span className="rounded-full bg-rose-50 px-2.5 py-1 text-xs font-bold text-rose-700 dark:bg-rose-950 dark:text-rose-200">{contact.relationship}</span>
              </div>
              <p className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm text-slate-500 dark:text-slate-400">
                <span className="inline-flex items-center gap-1"><Phone size={14} /> {contact.phone || "No phone"}</span>
                <span className="inline-flex items-center gap-1"><Mail size={14} /> {contact.email || "No email"}</span>
              </p>
            </div>
            <button onClick={() => remove(contact._id)} className="rounded-lg p-2 text-rose-600 transition hover:bg-rose-50 dark:hover:bg-rose-950" aria-label="Delete contact">
              <Trash2 size={18} />
            </button>
          </article>
        ))}
      </section>
    </div>
  );
}
