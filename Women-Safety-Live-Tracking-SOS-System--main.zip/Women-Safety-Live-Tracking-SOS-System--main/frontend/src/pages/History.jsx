import { Clock3, MapPinned, Radio, Video } from "lucide-react";
import { useEffect, useState } from "react";
import api from "../services/api";

export default function History() {
  const [items, setItems] = useState([]);

  useEffect(() => {
    api.get("/emergencies/history").then(({ data }) => setItems(data.emergencies));
  }, []);

  return (
    <div className="p-4 md:p-8">
      <div className="glass-panel rounded-lg p-5">
        <p className="text-sm font-bold uppercase text-rose-600 dark:text-rose-300">Emergency timeline</p>
        <h2 className="mt-1 text-3xl font-black">Emergency History</h2>
        <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">Review previous SOS sessions, tracking routes, recordings, and session status.</p>
      </div>

      <div className="mt-6 grid gap-3">
        {items.map((item) => (
          <article key={item._id} className="rounded-lg border border-white/70 bg-white/80 p-5 shadow-soft dark:border-slate-800 dark:bg-slate-900/75">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="font-black capitalize">{item.triggerType} SOS</p>
                <p className="mt-1 inline-flex items-center gap-1 text-sm text-slate-500 dark:text-slate-400">
                  <Clock3 size={14} /> {new Date(item.startedAt).toLocaleString()}
                </p>
              </div>
              <span className={`rounded-full px-3 py-1 text-sm font-bold ${item.status === "active" ? "bg-rose-600 text-white" : "bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-100"}`}>{item.status}</span>
            </div>
            <div className="mt-4 grid gap-2 text-sm text-slate-500 dark:text-slate-400 sm:grid-cols-3">
              <span className="inline-flex items-center gap-2 rounded-lg bg-slate-100 px-3 py-2 dark:bg-slate-800"><MapPinned size={15} /> {item.route?.length || 0} route points</span>
              <span className="inline-flex items-center gap-2 rounded-lg bg-slate-100 px-3 py-2 dark:bg-slate-800"><Video size={15} /> {item.media?.length || 0} media files</span>
              <span className="inline-flex items-center gap-2 rounded-lg bg-slate-100 px-3 py-2 dark:bg-slate-800"><Radio size={15} /> {item.dangerSignals?.length || 0} danger signals</span>
            </div>
          </article>
        ))}
        {!items.length && <p className="rounded-lg border border-dashed border-slate-300 bg-white/50 p-8 text-center text-slate-500 dark:border-slate-700 dark:bg-slate-900/40">No emergency sessions yet.</p>}
      </div>
    </div>
  );
}
