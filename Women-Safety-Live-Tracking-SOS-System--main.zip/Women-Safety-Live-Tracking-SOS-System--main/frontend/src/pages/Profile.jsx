import { HeartPulse, Save } from "lucide-react";
import { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import api from "../services/api";
import QRSafetyCard from "../components/QRSafetyCard";

export default function Profile() {
  const { user, updateProfile } = useAuth();
  const [form, setForm] = useState({
    name: "",
    phone: "",
    homeAddress: "",
    bloodGroup: "",
    allergies: "",
    emergencyDiseases: "",
    medicalHistory: "",
    medicalNotes: ""
  });
  const [saved, setSaved] = useState(false);
  const [contacts, setContacts] = useState([]);
  const [contactsLoading, setContactsLoading] = useState(true);

  useEffect(() => {
    api.get("/contacts")
      .then(({ data }) => setContacts(data.contacts || []))
      .catch(() => setContacts([]))
      .finally(() => setContactsLoading(false));
  }, []);

  useEffect(() => {
    setForm({
      name: user?.name || "",
      phone: user?.phone || "",
      homeAddress: user?.homeAddress || "",
      bloodGroup: user?.bloodGroup || "",
      allergies: user?.allergies || "",
      emergencyDiseases: user?.emergencyDiseases || "",
      medicalHistory: user?.medicalHistory || "",
      medicalNotes: user?.medicalNotes || ""
    });
  }, [user]);

  async function submit(event) {
    event.preventDefault();
    await updateProfile(form);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  return (
    <div className="p-4 md:p-8">
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Profile Form */}
        <form onSubmit={submit} className="glass-panel rounded-lg p-5 lg:col-span-2">
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-lg bg-rose-600 text-white">
              <HeartPulse size={20} />
            </span>
            <div>
              <h2 className="text-2xl font-black">Safety Profile</h2>
              <p className="text-sm text-slate-500 dark:text-slate-400">Keep emergency responders and contacts informed.</p>
            </div>
          </div>

          <div className="mt-5 grid gap-3 md:grid-cols-2">
            <input className="soft-input rounded-lg px-3 py-2" placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <input className="soft-input rounded-lg px-3 py-2" placeholder="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            <input className="soft-input rounded-lg px-3 py-2 md:col-span-2" placeholder="Home address" value={form.homeAddress} onChange={(e) => setForm({ ...form, homeAddress: e.target.value })} />
            <input className="soft-input rounded-lg px-3 py-2" placeholder="Blood group" value={form.bloodGroup} onChange={(e) => setForm({ ...form, bloodGroup: e.target.value })} />
            <input className="soft-input rounded-lg px-3 py-2" placeholder="Allergies" value={form.allergies} onChange={(e) => setForm({ ...form, allergies: e.target.value })} />
            <input className="soft-input rounded-lg px-3 py-2" placeholder="Emergency diseases" value={form.emergencyDiseases} onChange={(e) => setForm({ ...form, emergencyDiseases: e.target.value })} />
            <textarea className="soft-input min-h-28 rounded-lg px-3 py-2 md:col-span-2" placeholder="Medical history" value={form.medicalHistory} onChange={(e) => setForm({ ...form, medicalHistory: e.target.value })} />
            <textarea className="soft-input min-h-28 rounded-lg px-3 py-2 md:col-span-2" placeholder="Medical notes" value={form.medicalNotes} onChange={(e) => setForm({ ...form, medicalNotes: e.target.value })} />
          </div>

          <div className="mt-5 rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-900 dark:border-rose-900 dark:bg-rose-950/40 dark:text-rose-100">
            Blood group, allergies, emergency diseases, and medical history can help hospitals act faster during emergencies.
          </div>

          <button className="mt-5 inline-flex items-center gap-2 rounded-lg bg-slate-950 px-5 py-3 font-bold text-white shadow-sm transition hover:-translate-y-0.5 dark:bg-white dark:text-slate-950">
            <Save size={18} /> Save Profile
          </button>
          {saved && <span className="ml-3 text-sm font-semibold text-emerald-600">Saved</span>}
        </form>

        {/* QR Safety Card */}
        <div className="lg:col-span-1">
          {!contactsLoading && <QRSafetyCard user={user} contacts={contacts} />}
        </div>
      </div>
    </div>
  );
}
