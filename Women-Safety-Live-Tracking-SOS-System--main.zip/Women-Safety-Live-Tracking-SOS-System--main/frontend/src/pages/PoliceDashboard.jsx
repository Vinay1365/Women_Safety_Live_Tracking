import { useEffect, useMemo, useState } from "react";
import { AlertTriangle, Clock, History, Mail, MapPin, Phone, ShieldCheck, UserRound } from "lucide-react";
import LiveMap from "../components/LiveMap";
import api from "../services/api";

function formatDateTime(value) {
  if (!value) return "Unknown";
  return new Date(value).toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
}

function getVictimName(alert) {
  return alert.user?.name || "Unknown victim";
}

export default function PoliceDashboard() {
  const [alerts, setAlerts] = useState([]);
  const [history, setHistory] = useState([]);
  const [heatmapAreas, setHeatmapAreas] = useState([]);
  const [heatmapSummary, setHeatmapSummary] = useState(null);
  const [selectedId, setSelectedId] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;

    async function loadPoliceData() {
      try {
        const [activeResponse, historyResponse] = await Promise.all([
          api.get("/police/alerts/active"),
          api.get("/police/emergencies/history")
        ]);

        if (!active) return;
        setAlerts(activeResponse.data.alerts || []);
        setHistory(historyResponse.data.emergencies || []);
        setSelectedId((current) => current || activeResponse.data.alerts?.[0]?._id || null);
        setError("");
      } catch (err) {
        if (!active) return;
        setError(err.response?.data?.message || "Unable to load police portal data.");
      }
    }

    loadPoliceData();
    const interval = setInterval(loadPoliceData, 15_000);

    return () => {
      active = false;
      clearInterval(interval);
    };
  }, []);

  const selectedAlert = useMemo(
    () => alerts.find((alert) => alert._id === selectedId) || alerts[0] || null,
    [alerts, selectedId]
  );

  const location = selectedAlert?.latestLocation || selectedAlert?.initialLocation || null;
  const route = selectedAlert?.route || [];
  const activeCount = alerts.length;
  const endedCount = history.filter((item) => item.status === "ended").length;

  useEffect(() => {
    if (!location) return;

    api
      .get(`/safety/heatmap?lat=${location.lat}&lng=${location.lng}`)
      .then(({ data }) => {
        setHeatmapAreas(data.areas || []);
        setHeatmapSummary(data.summary || null);
      })
      .catch(() => {
        setHeatmapAreas([]);
        setHeatmapSummary(null);
      });
  }, [location]);

  return (
    <div className="grid gap-6 p-4 md:p-8">
      <section className="glass-panel rounded-lg p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-sm font-bold uppercase text-rose-600 dark:text-rose-300">Police Integration Dashboard</p>
            <h2 className="mt-1 text-3xl font-black tracking-normal md:text-4xl">Active SOS response portal</h2>
            <p className="mt-2 max-w-2xl text-sm text-slate-500 dark:text-slate-400">
              View active SOS alerts, track victim location, and review emergency history from one secured police workspace.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="rounded-lg bg-rose-600 px-4 py-3 text-white">
              <p className="text-xs font-bold uppercase opacity-80">Active alerts</p>
              <p className="text-2xl font-black">{activeCount}</p>
            </div>
            <div className="rounded-lg bg-slate-950 px-4 py-3 text-white dark:bg-white dark:text-slate-950">
              <p className="text-xs font-bold uppercase opacity-70">Resolved</p>
              <p className="text-2xl font-black">{endedCount}</p>
            </div>
          </div>
        </div>
        {error && <p className="mt-4 rounded-lg bg-rose-50 p-3 text-sm font-bold text-rose-700 dark:bg-rose-950/60 dark:text-rose-200">{error}</p>}
      </section>

      <section className="grid gap-6 xl:grid-cols-[390px_1fr]">
        <div className="grid content-start gap-4">
          <div className="glass-panel rounded-lg p-4">
            <h3 className="flex items-center gap-2 font-black">
              <AlertTriangle size={18} /> Active SOS alerts
            </h3>
            <div className="mt-3 grid gap-2">
              {alerts.length ? alerts.map((alert) => (
                <button
                  type="button"
                  key={alert._id}
                  onClick={() => setSelectedId(alert._id)}
                  className={`rounded-lg p-3 text-left text-sm transition hover:-translate-y-0.5 ${
                    selectedAlert?._id === alert._id
                      ? "bg-rose-600 text-white shadow-lg shadow-rose-950/15"
                      : "bg-white shadow-sm dark:bg-slate-800"
                  }`}
                >
                  <div className="flex items-center justify-between gap-3">
                    <span className="font-black">{getVictimName(alert)}</span>
                    <span className="rounded-full bg-white/20 px-2 py-1 text-xs font-black uppercase">{alert.status}</span>
                  </div>
                  <p className="mt-1 flex items-center gap-1 text-xs opacity-80">
                    <Clock size={13} /> {formatDateTime(alert.startedAt)}
                  </p>
                </button>
              )) : (
                <p className="rounded-lg bg-slate-100 p-3 text-sm text-slate-500 dark:bg-slate-800 dark:text-slate-400">
                  No active SOS alerts right now.
                </p>
              )}
            </div>
          </div>

          <div className="glass-panel rounded-lg p-4">
            <h3 className="flex items-center gap-2 font-black">
              <UserRound size={18} /> Victim details
            </h3>
            {selectedAlert ? (
              <div className="mt-3 grid gap-3 text-sm">
                <div className="rounded-lg bg-slate-100 p-3 dark:bg-slate-800">
                  <p className="font-black">{getVictimName(selectedAlert)}</p>
                  <p className="mt-1 flex items-center gap-2 text-slate-500 dark:text-slate-400"><Phone size={14} /> {selectedAlert.user?.phone || "Phone unavailable"}</p>
                  <p className="mt-1 flex items-center gap-2 text-slate-500 dark:text-slate-400"><Mail size={14} /> {selectedAlert.user?.email || "Email unavailable"}</p>
                </div>
                <div className="rounded-lg bg-slate-100 p-3 dark:bg-slate-800">
                  <p className="font-black">Medical notes</p>
                  <p className="mt-1 text-slate-500 dark:text-slate-400">
                    Blood group: {selectedAlert.user?.bloodGroup || "Unknown"}
                  </p>
                  <p className="text-slate-500 dark:text-slate-400">
                    Conditions: {selectedAlert.user?.emergencyDiseases || selectedAlert.user?.medicalNotes || "None provided"}
                  </p>
                </div>
                <div className="rounded-lg bg-slate-100 p-3 dark:bg-slate-800">
                  <p className="font-black">Trusted contacts notified</p>
                  <div className="mt-2 grid gap-2">
                    {selectedAlert.notifiedContacts?.length ? selectedAlert.notifiedContacts.map((contact) => (
                      <p key={contact._id} className="text-slate-500 dark:text-slate-400">
                        {contact.name} ({contact.relationship}) - {contact.phone || contact.email || "No contact info"}
                      </p>
                    )) : <p className="text-slate-500 dark:text-slate-400">No contacts listed.</p>}
                  </div>
                </div>
              </div>
            ) : (
              <p className="mt-3 rounded-lg bg-slate-100 p-3 text-sm text-slate-500 dark:bg-slate-800 dark:text-slate-400">
                Select an active alert to view victim details.
              </p>
            )}
          </div>
        </div>

        <div className="grid gap-4">
          <div className="glass-panel overflow-hidden rounded-lg p-3">
            <LiveMap location={location} route={route} heatmapAreas={heatmapAreas} />
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <div className="rounded-lg border border-white/70 bg-white/80 p-4 shadow-soft dark:border-slate-800 dark:bg-slate-900/75">
              <h3 className="flex items-center gap-2 font-black"><MapPin size={18} /> Latest victim location</h3>
              <div className="mt-3 rounded-lg bg-slate-100 p-3 text-sm dark:bg-slate-800">
                {location ? (
                  <>
                    <p className="font-bold">{Math.round(location.lat * 10000) / 10000}, {Math.round(location.lng * 10000) / 10000}</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Updated {formatDateTime(location.timestamp)}</p>
                  </>
                ) : (
                  <p className="text-slate-500 dark:text-slate-400">Location unavailable.</p>
                )}
              </div>
            </div>

            <div className="rounded-lg border border-white/70 bg-white/80 p-4 shadow-soft dark:border-slate-800 dark:bg-slate-900/75">
              <h3 className="flex items-center gap-2 font-black"><History size={18} /> Emergency history</h3>
              <div className="mt-3 grid max-h-72 gap-2 overflow-auto pr-1">
                {history.length ? history.slice(0, 8).map((item) => (
                  <div key={item._id} className="rounded-lg bg-slate-100 px-3 py-2 text-sm dark:bg-slate-800">
                    <div className="flex items-center justify-between gap-3">
                      <span className="font-bold">{getVictimName(item)}</span>
                      <span className="text-xs font-black uppercase text-slate-500 dark:text-slate-400">{item.status}</span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{formatDateTime(item.startedAt)}</p>
                  </div>
                )) : (
                  <p className="text-sm text-slate-500 dark:text-slate-400">No emergency history yet.</p>
                )}
              </div>
            </div>
          </div>

          <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-900 shadow-soft dark:border-emerald-900/70 dark:bg-emerald-950/40 dark:text-emerald-100">
            <h3 className="flex items-center gap-2 font-black"><ShieldCheck size={18} /> Government-ready response layer</h3>
            <p className="mt-2 opacity-80">
              This portal separates police access from citizen access and gives responders a live operational view of SOS incidents.
            </p>
            {heatmapSummary && (
              <p className="mt-2 font-bold">
                Heatmap: {heatmapSummary.safe} safe, {heatmapSummary.moderate} moderate, {heatmapSummary.high} high-risk zones from {heatmapSummary.incidentsAnalyzed} incidents.
              </p>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
