import { createContext, useContext, useEffect, useMemo, useState } from "react";
import api from "../services/api";
import { disconnectSocket } from "../services/socket";

const USER_CACHE_KEY = "safety_user_snapshot";

const AuthContext = createContext(null);

function readCachedUser() {
  try {
    const cachedUser = localStorage.getItem(USER_CACHE_KEY);
    return cachedUser ? JSON.parse(cachedUser) : null;
  } catch {
    return null;
  }
}

function persistUser(user) {
  if (!user) {
    localStorage.removeItem(USER_CACHE_KEY);
    return;
  }

  localStorage.setItem(USER_CACHE_KEY, JSON.stringify(user));
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => readCachedUser());
  const [token, setToken] = useState(localStorage.getItem("safety_token"));
  const [loading, setLoading] = useState(Boolean(token));

  useEffect(() => {
    if (!token) {
      setLoading(false);
      return;
    }

    api
      .get("/auth/me")
      .then(({ data }) => {
        setUser(data.user);
        persistUser(data.user);
      })
      .catch((error) => {
        const cachedUser = readCachedUser();
        if (!error.response && cachedUser) {
          setUser(cachedUser);
          return;
        }

        logout();
      })
      .finally(() => setLoading(false));
  }, [token]);

  async function login(payload) {
    const { data } = await api.post("/auth/login", payload);
    localStorage.setItem("safety_token", data.token);
    setToken(data.token);
    setUser(data.user);
    persistUser(data.user);
    return data;
  }

  async function register(payload) {
    const { data } = await api.post("/auth/register", payload);
    localStorage.setItem("safety_token", data.token);
    setToken(data.token);
    setUser(data.user);
    persistUser(data.user);
    return data;
  }

  function logout() {
    localStorage.removeItem("safety_token");
    disconnectSocket();
    setToken(null);
    setUser(null);
    persistUser(null);
  }

  async function updateProfile(payload) {
    const { data } = await api.put("/users/profile", payload);
    setUser(data.user);
    persistUser(data.user);
  }

  const value = useMemo(
    () => ({ user, token, loading, login, register, logout, updateProfile }),
    [user, token, loading]
  );
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  return useContext(AuthContext);
}
