import { createContext, useContext, useEffect, useMemo, useRef, useState } from "react";
import api from "../services/api";
import { getSocket } from "../services/socket";
import { useAuth } from "./AuthContext";

const EmergencyContext = createContext(null);

function normalizePosition(position) {
  return {
    lat: position.coords.latitude,
    lng: position.coords.longitude,
    accuracy: position.coords.accuracy,
    speed: position.coords.speed,
    heading: position.coords.heading,
    timestamp: new Date().toISOString()
  };
}

export function EmergencyProvider({ children }) {
  const { token, user } = useAuth();
  const [activeEmergency, setActiveEmergency] = useState(null);
  const [currentLocation, setCurrentLocation] = useState(null);
  const [status, setStatus] = useState("safe");
  const watchId = useRef(null);

  function stopLocationWatch() {
    if (watchId.current && typeof navigator !== "undefined") {
      navigator.geolocation.clearWatch(watchId.current);
    }
    watchId.current = null;
  }

  useEffect(() => {
    if (!token) return;
    const socket = getSocket(token);

    const handleLocationUpdate = (payload) => setCurrentLocation(payload.location);
    const handleEmergencyEnd = () => {
      stopLocationWatch();
      setStatus("safe");
      setActiveEmergency(null);
    };

    socket?.on("emergency:location", handleLocationUpdate);
    socket?.on("emergency:end", handleEmergencyEnd);

    return () => {
      socket?.off("emergency:location", handleLocationUpdate);
      socket?.off("emergency:end", handleEmergencyEnd);
      stopLocationWatch();
    };
  }, [token]);

  useEffect(() => {
    return () => stopLocationWatch();
  }, []);

  function getCurrentPosition() {
    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(resolve, reject, {
        enableHighAccuracy: true,
        timeout: 12000,
        maximumAge: 0
      });
    });
  }

  async function startEmergency(triggerType = "button") {
    setStatus("starting");
    const position = await getCurrentPosition();
    const location = normalizePosition(position);
    setCurrentLocation(location);

    const { data } = await api.post("/emergencies/start", {
      triggerType,
      location,
      message: `${user?.name || "User"} activated emergency SOS`
    });

    setActiveEmergency(data.emergency);
    setStatus("active");
    startLocationWatch(data.emergency._id);
    return data.emergency;
  }

  function startLocationWatch(emergencyId) {
    stopLocationWatch();

    const socket = getSocket(token);
    socket?.emit("tracking:join", emergencyId);

    watchId.current = navigator.geolocation.watchPosition(
      async (position) => {
        const location = normalizePosition(position);
        setCurrentLocation(location);
        socket?.emit("tracking:location", { emergencyId, location });
        const { data } = await api.patch(`/emergencies/${emergencyId}/location`, { location });
        setActiveEmergency(data.emergency);
      },
      (error) => console.error("Location watch failed:", error),
      { enableHighAccuracy: true, maximumAge: 3000, timeout: 10000 }
    );
  }

  async function endEmergency() {
    if (!activeEmergency) return;
    await api.patch(`/emergencies/${activeEmergency._id}/end`);
    stopLocationWatch();
    setActiveEmergency(null);
    setStatus("safe");
  }

  const value = useMemo(
    () => ({ activeEmergency, currentLocation, status, startEmergency, endEmergency }),
    [activeEmergency, currentLocation, status]
  );

  return <EmergencyContext.Provider value={value}>{children}</EmergencyContext.Provider>;
}

export function useEmergency() {
  return useContext(EmergencyContext);
}
