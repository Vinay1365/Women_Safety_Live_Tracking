# Women Safety Frontend

React + Vite app with authentication, contact management, SOS activation, live Google Maps tracking, audio/video recording controls, chatbot assistance, nearby emergency places, history, and dark/light mode.

## Setup

```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```

Add a Google Maps JavaScript API key to `VITE_GOOGLE_MAPS_API_KEY`.
