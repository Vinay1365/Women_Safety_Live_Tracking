# Women Safety Application With Live Tracking

Full-stack safety platform with a React frontend and Node.js/Express/MongoDB backend.

## Project Structure

```text
frontend/  React, React Router, Context API, Tailwind CSS, Google Maps, Socket.IO client
backend/   Express REST API, MongoDB models, JWT auth, Socket.IO, alerts, media upload hooks
```

## ⭐ New Features (June 2026)

✨ **AI Voice Sentiment Analysis** - Real-time panic detection during audio recording with automatic emergency contact notification
✨ **Analytics Dashboard** - Beautiful statistics showing SOS alerts, safe routes, dangerous locations, and monthly trends
✨ **QR Safety Card** - Generate QR codes with personal medical info for police and hospitals to scan

## Core Features

- Secure registration, login, JWT authentication, and profile management
- Trusted emergency contact management
- Emergency SOS activation with live GPS sharing
- Real-time location updates through Socket.IO
- Google Maps live tracking UI
- Audio and video recording during active emergencies
- Local media upload with cloud storage integration point
- Email/SMS notification hooks using Nodemailer and Twilio
- Emergency history dashboard
- Dark/light responsive mobile-friendly interface
- Voice SOS trigger, fake call trigger, nearby emergency place locator, and chatbot assistance
- **NEW**: AI-powered voice stress analysis and panic detection
- **NEW**: Comprehensive analytics dashboard with data visualization
- **NEW**: QR safety card generation and download

## Run Backend

```bash
cd backend
copy .env.example .env
npm install
npm run dev
```

Set `MONGODB_URI` and `JWT_SECRET` in `backend/.env`. Add Twilio/SMTP/Firebase values only when you want real notifications or cloud uploads.

## Run Frontend

```bash
cd frontend
copy .env.example .env
npm install
npm run dev
```

Set `VITE_GOOGLE_MAPS_API_KEY` in `frontend/.env` to enable the live map.

## Local URLs

- Frontend: `http://localhost:5173`
- Backend API: `http://localhost:5000/api`
- Health check: `http://localhost:5000/api/health`

## 📚 Documentation

### For Users
👉 **[USER_GUIDE.md](USER_GUIDE.md)** - Complete guide explaining every feature with real-world examples
- How to use each feature
- What information is visible to whom
- Privacy and security
- Getting started guide
- FAQ and troubleshooting

👉 **[FEATURES.md](FEATURES.md)** - Quick reference list of all 80+ features
- Feature checklist
- Feature availability by user type
- Technical capabilities

### Getting Started
1. See [USER_GUIDE.md](USER_GUIDE.md) **"Getting Started Guide"** section
2. Create account and verify email
3. Add emergency contacts
4. Download your QR Safety Card
5. Test SOS button
6. Explore analytics and voice features

## 🎯 Key Highlights

### Voice Sentiment Analysis ⭐
- Real-time AI analysis of your voice during audio recording
- Detects panic (stress level >80%)
- Automatically notifies emergency contacts with stress percentage
- Shows live metrics: frequency, energy, tension levels
- 50 analyses per second using Web Audio API

### Analytics Dashboard ⭐
- Beautiful charts and statistics
- Total SOS alerts, safe routes, dangerous locations
- Monthly trends (12 months)
- Emergency breakdown by type (pie chart)
- Perfect for presentations and analysis

### QR Safety Card ⭐
- Encode medical info in QR code
- Police/hospitals can scan to get:
  - Your name and contact
  - Blood group
  - Allergies
  - Medical history
  - Emergency contacts
- Download as PNG and print/carry
