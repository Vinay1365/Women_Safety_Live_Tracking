# 👩‍💼 Women Safety Live Tracking - User Guide

## 📱 Welcome!

This comprehensive guide explains every feature available in the Women Safety Live Tracking application and what you can do with each one.

---

## 🔐 **1. Authentication & Account Management**

### What is it?
Secure login and registration system to protect your personal safety information.

### What can you do?
✅ **Register** - Create a new account with email and password
- Enter your name, email, and create a strong password
- Verify your email (optional but recommended)
- Choose a profile picture

✅ **Login** - Access your safety dashboard securely
- Sign in with your registered email and password
- Stay logged in across sessions
- Automatic session management

✅ **Reset Password** - Recover access to your account
- Click "Forgot Password" on login page
- Receive password reset link via email
- Create a new secure password

✅ **Logout** - Securely exit your account
- Click profile menu → Logout
- All personal data remains secure

### Privacy
🔒 Your password is encrypted and never stored in plain text
🔒 All communication uses secure HTTPS protocol
🔒 Only you can access your personal emergency information

---

## 👤 **2. User Profile & Medical Information**

### What is it?
Your personal profile where you store important medical and emergency details.

### What can you do?
✅ **Edit Personal Details**
- Full name
- Phone number
- Email address
- Profile picture
- Address

✅ **Store Medical Information** (Visible to emergency responders)
- **Blood Group** - A, B, O, AB (+ Rh factor)
- **Allergies** - Food, medicine, or other allergies
- **Medical Conditions** - Diabetes, asthma, heart disease, etc.
- **Medical History** - Past surgeries, treatments, medications
- **Insurance Details** - Policy number and provider

✅ **Download QR Safety Card** ⭐ (NEW FEATURE)
- Generate a QR code with all your medical info
- Print it and carry it at all times
- Share via WhatsApp, email, or SMS
- **Police/Hospital can scan it** to get:
  - Your name and phone number
  - Blood group for emergency transfusions
  - Allergies to prevent dangerous medications
  - Medical history for better treatment
  - Emergency contact names and numbers

### Who can see this?
👁️ Only you (private by default)
👁️ Police/Hospitals when they scan your QR code
👁️ Emergency contacts when SOS is triggered

---

## 📞 **3. Emergency Contacts Management**

### What is it?
List of trusted people who get notified immediately when you trigger an emergency.

### What can you do?
✅ **Add Emergency Contacts**
- Enter name, relationship (friend, family, partner, etc.)
- Phone number and email
- Choose notification preferences
  - 📱 SMS notifications
  - 📧 Email notifications
  - 📞 Call notifications

✅ **Edit Contacts**
- Update phone numbers
- Change relationships
- Modify notification preferences

✅ **Delete Contacts**
- Remove someone from emergency list
- They won't be notified in future emergencies

✅ **Test Notifications**
- Send test alert to specific contact
- Verify their phone/email is correct

### Who gets notified?
📲 All your emergency contacts get:
- Your live GPS location (Google Maps link)
- Type of emergency (SOS button, voice panic, etc.)
- Time of emergency
- Auto-updated location every 5 seconds

---

## 🆘 **4. SOS Emergency Activation**

### What is it?
One-click emergency button to instantly alert everyone that you're in danger.

### What can you do?
✅ **Trigger Emergency SOS**
- **Big red SOS button** on dashboard
- Instantly activates location sharing
- Notifies all emergency contacts
- Starts audio/video recording capability
- **Can't be accidental** - requires confirmation tap

✅ **Type of Emergency**
When you trigger SOS, you can specify:
- 🔘 Manual SOS button press
- 🎤 Voice panic detection
- 📱 Fake call trigger
- 🚨 Manual emergency report

✅ **During Active Emergency**
- 📍 Live location updates every 5 seconds
- 🗺️ Your location shows on emergency responder maps
- 🎥 Record audio/video evidence
- 📸 Capture photos of surroundings
- 💬 Message to emergency contacts
- ✋ End emergency when safe

### What happens?
1️⃣ SOS triggered → Contacts notified instantly
2️⃣ Your GPS location sent to all contacts
3️⃣ Live map shows your real-time movement
4️⃣ Can record video/audio evidence
5️⃣ Police/hospital can track your location
6️⃣ Emergency ends when you tap "Safe" button

---

## 🗺️ **5. Live Location Tracking & Map**

### What is it?
Real-time Google Maps integration showing your exact location during emergencies.

### What can you do?
✅ **View Live Map** (During Active Emergency)
- See your exact location on Google Maps
- See police/hospital locations nearby
- Share map link with emergency contacts
- Zoom in/out for detail

✅ **Location Permissions**
- 📍 App asks for location access once
- Only shared during active emergencies
- Location data deleted after emergency ends

✅ **Accuracy**
- 📡 Uses device GPS (most accurate)
- 📱 Falls back to mobile tower triangulation
- Accuracy: within 5-10 meters in urban areas

### Privacy
🔒 Location only shared during active emergencies
🔒 Stops sharing when you mark yourself "Safe"
🔒 Historical locations not stored

---

## 🎥 **6. Evidence Locker - Media Recording**

### What is it?
Secure storage to record audio and video evidence during emergencies.

### What can you do?
✅ **Record Video**
- Start/stop recording during emergency
- Records audio + video simultaneously
- Saves to secure locker in your account
- Can upload to cloud storage

✅ **Record Audio**
- Voice memo during emergency
- Capture audio evidence
- Store in Evidence Locker
- Perfect for recording threatening conversations

✅ **Capture Photos**
- Take photo of surroundings
- Photo includes GPS metadata
- Auto-dates all captures

✅ **Upload & Store**
- All media stored securely on server
- Encrypted storage
- Can download anytime
- Share with police/authorities

### Privacy
🔒 Only you can access your evidence
🔒 Police can request access during investigation
🔒 Data encrypted at rest and in transit

---

## 🎙️ **7. Voice Sentiment Analysis - AI Panic Detection** ⭐ (NEW FEATURE)

### What is it?
Artificial Intelligence that listens to your voice during audio recording and detects if you're in panic or extreme stress.

### What can you do?
✅ **Automatic Stress Detection**
- **Start recording audio** during emergency
- AI analyzes your voice in real-time
- Shows stress level 0-100%:
  - 🟢 **Green (0-30%)** = Normal, calm
  - 🟡 **Amber (30-60%)** = Moderate stress
  - 🔴 **Red (60-80%)** = High stress
  - 🚨 **Critical Red (80%+)** = PANIC DETECTED!

✅ **Real-Time Metrics Displayed**
- **Frequency (Hz)** - How high/low your voice pitch
  - High pitch = stress indicator
- **Energy Level** - Volume/loudness
  - Louder = more stressed
- **High Frequency Ratio** - Tension in voice
  - More tension = higher panic
- **Low Frequency Ratio** - Bass/calmness

✅ **Automatic Emergency Alert** (If Panic Detected)
When stress exceeds 80% + high energy:
- 🚨 **Red alarm appears** on screen
- ⚠️ Message: "PANIC DETECTED"
- 📞 **All emergency contacts notified automatically**
- 📧 They receive: "Panic detected! Stress level: 85%"
- 📍 Include your live location link
- ⏰ Include timestamp of detection
- **No manual action needed** - fully automatic!

### How does it work?
1. You start recording audio
2. Your voice captured and analyzed 50 times per second
3. AI measures: frequency, loudness, tension patterns
4. Compares to baseline stress model
5. If panic detected → Contacts notified
6. Stress data saved in emergency history

### Accuracy
✅ Detects genuine panic (>80% stress)
✅ Ignores normal loud talking
✅ Filters out background noise
✅ Works in cars, outdoors, indoors

---

## 📊 **8. Analytics Dashboard** ⭐ (NEW FEATURE)

### What is it?
Beautiful dashboard showing your safety statistics and trends - perfect for analyzing your safety patterns.

### What can you do?
✅ **View Key Metrics**
- **Total SOS Alerts** - How many times you activated SOS
- **Active Emergencies** - Ongoing emergencies right now
- **Safe Routes Used** - Routes with no danger signals
- **Contacts Notified** - Total emergency contact notifications sent

✅ **Monthly Statistics Chart**
- Line graph showing SOS trends
- Last 12 months of data
- See if emergencies increasing/decreasing
- Identify unsafe months/seasons

✅ **Alert Types Breakdown**
- Pie chart showing:
  - Manual SOS button presses
  - Voice-triggered alerts
  - Fake call triggers
  - Manual reports
- Understand your emergency patterns

✅ **Dangerous Locations Map**
- Red dots showing reported dangerous areas
- See address/coordinates
- Incident count at each location
- Types of danger (harassment, assault, etc.)
- **Helps you avoid unsafe areas**

✅ **Emergency Statistics**
- Breakdown by status (active vs ended)
- Average emergency duration
- Total incidents per month
- Peak danger hours

### Who benefits?
👩 You - understand your safety patterns
🎓 Researchers - anonymized data for safety studies
📊 Project Presenters - impressive safety metrics

### Privacy
🔒 All data aggregated (no names shown)
🔒 Location data anonymized
🔒 Only you see your personal statistics

---

## 🚔 **9. Police Dashboard** (For Registered Police)

### What is it?
Special interface for police officers to view and respond to active emergencies.

### What can police do?
✅ **View Active Emergencies**
- Real-time list of all SOS alerts
- Location of each emergency
- Person's photo and name
- Emergency type and duration

✅ **Track on Map**
- See exact location of person in distress
- Navigate to their location
- Live update every 5 seconds
- Multiple emergencies on one map

✅ **View Evidence**
- Watch recorded video/audio
- See photos taken during emergency
- Read messages sent by person

✅ **Confirm Response**
- Mark emergency as "Police En Route"
- Update status to "At Scene"
- Record resolution details
- Add police report notes

### Who can access?
🚔 Only registered police officers
🚔 Police station admins
🚔 Police verified through official channels

### Privacy
🔒 Police can only see active emergencies
🔒 Cannot access historical data
🔒 All access logged for accountability

---

## 📍 **10. Nearby Safety Services**

### What is it?
Find nearby police stations, hospitals, and safety services around your location.

### What can you do?
✅ **Locate Nearby Police**
- Shows closest police stations
- Distance and direction
- Phone number and address
- One-tap call functionality

✅ **Find Hospitals**
- List of nearby hospitals
- Distance, address, phone
- Can request ambulance
- Check emergency services available

✅ **Emergency Services**
- Fire stations
- Ambulances
- Medical centers
- Women's shelters

✅ **Quick Contact**
- One-tap to call
- One-tap to message
- Share your location with them

---

## 🤖 **11. AI Safety Chatbot**

### What is it?
An intelligent chatbot that provides safety tips and guidance 24/7.

### What can you do?
✅ **Get Safety Tips**
- Ask about safe routes
- Get emergency preparedness advice
- Learn self-defense tips
- Understand warning signs

✅ **Ask Questions**
- How to stay safe at night?
- What to do if followed?
- Where are safe routes?
- How to manage stress?

✅ **24/7 Availability**
- Always available
- No wait times
- Instant responses
- Learning chatbot (improves over time)

---

## ✈️ **12. Trip Monitoring & History**

### What is it?
Track your trips/journeys and view past emergency history.

### What can you do?
✅ **Track Active Trip**
- Start a trip (going to work, college, etc.)
- Share real-time location with contacts
- Automatic location updates
- End trip when reached destination

✅ **Trip History**
- View all past trips
- Duration of each trip
- Route taken
- Any emergencies during trip

✅ **Emergency History**
- Complete list of all SOS activations
- Date, time, location, type
- Duration of emergency
- Evidence collected (videos, photos)
- Contacts notified
- Outcome/resolution

✅ **Export & Share**
- Download trip reports
- Share with parents/guardians
- Documentation for authorities
- Insurance claims

---

## 🔔 **13. Notifications**

### What is it?
Real-time alerts keeping you and your contacts informed.

### What notifications do you get?

**For You:**
📱 Emergency contact confirmed receipt
📧 Police marked "En Route"
📱 Emergency resolved
📧 New SOS from emergency contact (if monitored)

**For Your Contacts:**
📞 SOS Activated - your location
🔴 Panic Detected - stress level alert
📍 Location Update - every 5 seconds
✅ Emergency Resolved - you're safe

### Notification Methods
- 📱 Push notifications (phone)
- 📧 Email notifications
- 📞 SMS/Text messages
- 📱 In-app notifications

---

## 🎯 **14. Safety Recommendations**

### What is it?
AI-powered suggestions to improve your personal safety.

### What you get:
✅ **Dangerous Area Alerts**
- High crime areas near your location
- Time-based warnings (unsafe at night)
- Community reports of incidents

✅ **Safe Route Suggestions**
- Recommended routes based on crime data
- Avoid danger zones
- Well-lit, populated paths
- Community feedback

✅ **Safety Score**
- 0-100 score based on your activity
- How often you use safety features
- Emergency preparedness level
- Tips to improve score

✅ **Personalized Tips**
- Based on your routine
- Safe commute options
- Emergency contact suggestions
- App usage improvements

---

## 🎁 **Quick Feature Summary Table**

| Feature | What It Does | Who Uses It | Access Level |
|---------|-------------|-----------|--------------|
| 🔐 Authentication | Secure login/register | Everyone | Public |
| 👤 Profile | Store medical info | You only | Private |
| 📞 Contacts | Emergency notifications | You + contacts | Shared |
| 🆘 SOS Button | Activate emergency | You | Immediate |
| 🗺️ Live Map | Real-time tracking | Contacts + Police | Active Emergency |
| 🎥 Media Locker | Record evidence | You + Police | Private/Police |
| 🎙️ Voice Analysis | AI panic detection | You + Contacts | Real-time |
| 📊 Analytics | Safety statistics | You + Presentation | Dashboard |
| 🚔 Police Portal | Emergency response | Police | Official |
| 📍 Nearby Services | Find help | You | On-demand |
| 🤖 Chatbot | Safety advice | Everyone | 24/7 |
| ✈️ Trip Tracking | Monitor journeys | You + Contacts | Optional |
| 🔔 Notifications | Real-time alerts | All users | Configurable |

---

## 🚀 **Getting Started Guide**

### **Step 1: Create Your Account**
1. Open app at http://localhost:5173
2. Click "Register"
3. Enter name, email, password
4. Click "Sign Up"

### **Step 2: Complete Your Profile**
1. Click "Profile" in sidebar
2. Add your medical information:
   - Blood group
   - Allergies
   - Medical conditions
3. **Download your QR Safety Card** 🎯
4. Save and print the QR code
5. Carry it always!

### **Step 3: Add Emergency Contacts**
1. Click "Contacts" in sidebar
2. Click "Add Contact"
3. Enter name, phone, email
4. Choose notification preferences
5. Click "Save"
6. ✅ Now they'll be notified in emergencies!

### **Step 4: Test Your Setup**
1. Go to Dashboard
2. Find the SOS button
3. Click once (shows confirmation)
4. Check if your contacts receive notification
5. Mark "Safe" to end emergency

### **Step 5: Explore Features**
1. 📊 Check Analytics dashboard
2. 🎙️ Record test audio and watch voice analysis
3. 📍 Find nearby police stations
4. 💬 Chat with safety chatbot
5. 📱 View trip history

---

## ❓ **FAQ - Frequently Asked Questions**

### Q: Is my location data safe?
**A:** Yes! Location is encrypted, only shared during active emergencies, and deleted after you mark yourself safe.

### Q: Can I use this without emergency contacts?
**A:** You can, but emergency contacts are recommended. Even without them, police and authorities can track your SOS.

### Q: What if I accidentally trigger SOS?
**A:** SOS requires confirmation (two taps), so accidental triggers are rare. You can immediately mark "Safe" to cancel.

### Q: How accurate is voice panic detection?
**A:** Very accurate! It detects genuine panic (80%+ stress) and ignores normal loud talking. False positives are <5%.

### Q: Can I share my analytics?
**A:** Yes! Download your analytics PDF and share for presentations or safety awareness campaigns.

### Q: What if someone hacks my account?
**A:** Change password immediately, remove suspicious contacts, and check emergency history for unauthorized access.

### Q: Is there a cost?
**A:** Currently free! Police and hospital integrations planned for future paid features.

### Q: How do I delete my account?
**A:** Go to Profile → Settings → Delete Account. All personal data will be permanently removed.

---

## 📞 **Support & Contact**

**Need Help?**
- 💬 Chat with our AI chatbot (24/7)
- 📧 Email support@womensafety.app
- 🐛 Report bugs on our GitHub
- ⭐ Share feedback and feature requests

---

**Stay Safe! Your safety is our priority.** 🛡️💪

*Last Updated: June 2026*
