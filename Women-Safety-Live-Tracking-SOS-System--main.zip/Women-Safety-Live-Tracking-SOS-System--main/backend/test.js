const mongoose = require("mongoose");

const uri =
  "mongodb+srv://231fa044004_db_user:QDJjATCRz0Oa6AmO@cluster0.uku9enj.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

mongoose
  .connect(uri)
  .then(() => {
    console.log("✅ Connected");
    process.exit(0);
  })
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });