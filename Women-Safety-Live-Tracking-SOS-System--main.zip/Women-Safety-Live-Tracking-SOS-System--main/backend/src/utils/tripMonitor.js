const Contact = require("../models/Contact");
const Trip = require("../models/Trip");
const { notifyContacts } = require("./notifications");

function buildTripOverdueMessage(user, trip) {
  const loc = trip.latestLocation || trip.startLocation;
  const mapUrl = loc?.lat && loc?.lng ? `https://maps.google.com/?q=${loc.lat},${loc.lng}` : "Location unavailable";
  return `${user.name} has not reached ${trip.destination} by the expected time. Last known location: ${mapUrl}`;
}

async function alertOverdueTrips() {
  const overdueTrips = await Trip.find({
    status: "active",
    expectedArrivalAt: { $lte: new Date() },
    alertSent: false
  }).populate("user");

  await Promise.all(
    overdueTrips.map(async (trip) => {
      const contacts = await Contact.find({ user: trip.user._id }).sort({ priority: 1 });
      const message = buildTripOverdueMessage(trip.user, trip);

      notifyContacts(trip.user, contacts, trip, message, "Trip Overdue Alert").catch((error) => {
        console.error("Trip notification failure:", error.message);
      });

      trip.status = "overdue";
      trip.alertSent = true;
      trip.alertedAt = new Date();
      trip.notifiedContacts = contacts.map((contact) => contact._id);
      await trip.save();
    })
  );
}

function startTripMonitor() {
  alertOverdueTrips().catch((error) => console.error("Trip monitor failed:", error.message));

  const interval = setInterval(() => {
    alertOverdueTrips().catch((error) => console.error("Trip monitor failed:", error.message));
  }, Number(process.env.TRIP_MONITOR_INTERVAL_MS || 60_000));

  return () => clearInterval(interval);
}

module.exports = { startTripMonitor, alertOverdueTrips, buildTripOverdueMessage };
