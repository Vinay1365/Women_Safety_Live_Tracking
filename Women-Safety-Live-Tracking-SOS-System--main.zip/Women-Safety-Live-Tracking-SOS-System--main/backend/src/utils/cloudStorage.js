const fs = require("fs/promises");

async function uploadToCloudinary(file) {
  if (!process.env.CLOUDINARY_CLOUD_NAME || !process.env.CLOUDINARY_UPLOAD_PRESET) {
    return null;
  }

  const bytes = await fs.readFile(file.path);
  const formData = new FormData();
  formData.append("file", new Blob([bytes], { type: file.mimetype }), file.originalname);
  formData.append("upload_preset", process.env.CLOUDINARY_UPLOAD_PRESET);
  formData.append("folder", process.env.CLOUDINARY_EVIDENCE_FOLDER || "evidence-locker");
  formData.append("resource_type", file.mimetype.startsWith("video/") ? "video" : "raw");

  const resourceType = file.mimetype.startsWith("video/") ? "video" : "raw";
  const response = await fetch(`https://api.cloudinary.com/v1_1/${process.env.CLOUDINARY_CLOUD_NAME}/${resourceType}/upload`, {
    method: "POST",
    body: formData
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Cloudinary upload failed: ${errorText}`);
  }

  const data = await response.json();
  return {
    url: data.secure_url,
    cloudProvider: "cloudinary",
    publicId: data.public_id
  };
}

async function uploadMediaToCloud(file) {
  const cloudFile = await uploadToCloudinary(file);
  if (cloudFile) return cloudFile;

  // Local storage keeps development runnable when no cloud credentials are configured.
  return {
    url: `/uploads/${file.filename}`,
    cloudProvider: "local",
    publicId: file.filename
  };
}

module.exports = { uploadMediaToCloud };
