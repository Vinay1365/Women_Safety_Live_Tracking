const nodemailer = require("nodemailer");
const twilio = require("twilio");

function buildEmergencyMessage(user, emergency) {
  const loc = emergency.latestLocation || emergency.initialLocation;
  const mapUrl = loc?.lat && loc?.lng ? `https://maps.google.com/?q=${loc.lat},${loc.lng}` : "Location unavailable";
  return `${user.name} triggered an SOS alert. Track location: ${mapUrl}`;
}

async function sendEmail(contact, subject, body) {
  if (!contact.email || !process.env.SMTP_HOST) return { skipped: true };

  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: false,
    auth: process.env.SMTP_USER
      ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
      : undefined
  });

  await transporter.sendMail({
    from: process.env.SMTP_FROM,
    to: contact.email,
    subject,
    text: body
  });

  return { sent: true };
}

async function sendSms(contact, body) {
  if (!contact.phone || !process.env.TWILIO_ACCOUNT_SID) return { skipped: true };

  const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
  await client.messages.create({
    from: process.env.TWILIO_PHONE_NUMBER,
    to: contact.phone,
    body
  });

  return { sent: true };
}

async function notifyContacts(user, contacts, emergency, emergencyMessage, subject = "Emergency SOS Alert") {
  const body = emergencyMessage || buildEmergencyMessage(user, emergency);

  const results = await Promise.allSettled(
    contacts.flatMap((contact) => [
      contact.notifyByEmail ? sendEmail(contact, subject, body) : Promise.resolve({ skipped: true }),
      contact.notifyBySms ? sendSms(contact, body) : Promise.resolve({ skipped: true })
    ])
  );

  return results.map((result) => (result.status === "fulfilled" ? result.value : { error: result.reason.message }));
}

module.exports = { notifyContacts, buildEmergencyMessage };
