const nodemailer = require("nodemailer");

const otpStore = new Map();
const OTP_TTL_MS = 5 * 60 * 1000;

function makeKey(purpose, email) {
  return `${purpose}:${String(email).toLowerCase()}`;
}

function generateOtp() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

function isDevOtpEnabled() {
  return process.env.ENABLE_DEV_OTP === "true";
}

function logDevOtp(email, otp, purpose) {
  console.warn(`[DEV OTP] ${purpose} OTP for ${email}: ${otp}`);
}

function createOtpSession({ purpose, email, payload }) {
  const otp = generateOtp();
  const key = makeKey(purpose, email);
  otpStore.set(key, {
    otp,
    payload,
    attempts: 0,
    expiresAt: Date.now() + OTP_TTL_MS
  });
  return { otp, expiresInMinutes: OTP_TTL_MS / 60000 };
}

function verifyOtpSession({ purpose, email, otp }) {
  const key = makeKey(purpose, email);
  const session = otpStore.get(key);

  if (!session) {
    return { ok: false, message: "OTP not requested or expired" };
  }

  if (Date.now() > session.expiresAt) {
    otpStore.delete(key);
    return { ok: false, message: "OTP expired. Please request a new code" };
  }

  session.attempts += 1;
  if (session.attempts > 5) {
    otpStore.delete(key);
    return { ok: false, message: "Too many OTP attempts. Please request a new code" };
  }

  if (session.otp !== String(otp).trim()) {
    return { ok: false, message: "Invalid OTP" };
  }

  otpStore.delete(key);
  return { ok: true, payload: session.payload };
}

async function sendOtpEmail(email, otp, purpose) {
  if (!process.env.SMTP_HOST) {
    if (!isDevOtpEnabled()) {
      return { channel: "email", status: "skipped", reason: "SMTP is not configured" };
    }

    logDevOtp(email, otp, purpose);
    return { channel: "dev", status: "sent", to: email, reason: "SMTP is not configured" };
  }

  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: false,
    auth: process.env.SMTP_USER
      ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
      : undefined
  });

  await transporter.sendMail({
    from: process.env.SMTP_FROM,
    to: email,
    subject: `Your Sakhi Shield ${purpose} OTP`,
    text: `Your OTP is ${otp}. It expires in 5 minutes.`
  });

  return { channel: "email", status: "sent", to: email };
}

async function deliverOtp({ email, otp, purpose }) {
  const results = await Promise.allSettled([sendOtpEmail(email, otp, purpose)]);

  return results.map((result, index) =>
    result.status === "fulfilled"
      ? result.value
      : {
          channel: index === 0 ? "email" : "unknown",
          status: "error",
          reason: result.reason.message
        }
  );
}

module.exports = { createOtpSession, verifyOtpSession, deliverOtp };
