const bcrypt = require("bcryptjs");

const usersByEmail = new Map();
const usersById = new Map();

function publicUser(user) {
  const { passwordHash, ...safeUser } = user;
  return safeUser;
}

async function createUser({ name, email, phone, password, role }) {
  const normalizedEmail = String(email || "").trim().toLowerCase();
  if (usersByEmail.has(normalizedEmail)) {
    const error = new Error("Email already registered");
    error.statusCode = 409;
    throw error;
  }

  const now = new Date().toISOString();
  const user = {
    _id: `dev-${Date.now()}-${Math.random().toString(16).slice(2)}`,
    id: "",
    name,
    email: normalizedEmail,
    phone,
    role,
    preferences: {
      theme: "light",
      voiceSosPhrase: "help me",
      autoRecordAudio: true,
      autoRecordVideo: true
    },
    createdAt: now,
    updatedAt: now,
    passwordHash: await bcrypt.hash(password, 12)
  };
  user.id = user._id;

  usersByEmail.set(normalizedEmail, user);
  usersById.set(user.id, user);
  return publicUser(user);
}

async function verifyUser(email, password) {
  const normalizedEmail = String(email || "").trim().toLowerCase();
  const user = usersByEmail.get(normalizedEmail);
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
    return null;
  }

  return publicUser(user);
}

function findUserById(id) {
  const user = usersById.get(id);
  return user ? publicUser(user) : null;
}

module.exports = { createUser, findUserById, verifyUser };
