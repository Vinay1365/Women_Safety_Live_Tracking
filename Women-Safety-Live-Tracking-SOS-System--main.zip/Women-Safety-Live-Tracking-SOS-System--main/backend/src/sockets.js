const jwt = require("jsonwebtoken");
const { Server } = require("socket.io");

let io;

function initSocket(server) {
  io = new Server(server, {
    cors: {
      origin: process.env.CLIENT_URL || "http://localhost:5173",
      credentials: true
    }
  });

  io.use((socket, next) => {
    try {
      const token = socket.handshake.auth?.token;
      if (!token) return next(new Error("Authentication required"));
      socket.user = jwt.verify(token, process.env.JWT_SECRET);
      next();
    } catch (error) {
      next(new Error("Invalid socket token"));
    }
  });

  io.on("connection", (socket) => {
    const userRoom = `user:${socket.user.id}`;
    socket.join(userRoom);

    socket.on("tracking:join", (emergencyId) => socket.join(`emergency:${emergencyId}`));
    socket.on("tracking:location", (payload) => {
      socket.to(userRoom).emit("emergency:location", payload);
      if (payload.emergencyId) socket.to(`emergency:${payload.emergencyId}`).emit("emergency:location", payload);
    });
  });

  return io;
}

function emitEmergencyUpdate(userId, event, payload) {
  if (!io) return;
  io.to(`user:${userId}`).emit(event, payload);
  if (payload?.emergencyId || payload?._id) {
    io.to(`emergency:${payload.emergencyId || payload._id}`).emit(event, payload);
  }
}

module.exports = { initSocket, emitEmergencyUpdate };
