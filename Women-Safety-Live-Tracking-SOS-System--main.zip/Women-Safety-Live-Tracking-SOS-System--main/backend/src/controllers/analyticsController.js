const Emergency = require("../models/Emergency");
const Contact = require("../models/Contact");

async function getAnalytics(req, res, next) {
  try {
    const userId = req.user.id;
    
    // Total SOS alerts
    const totalAlerts = await Emergency.countDocuments({ user: userId });
    
    // Alerts by trigger type
    const alertsByType = await Emergency.aggregate([
      { $match: { user: req.user._id } },
      { $group: { _id: "$triggerType", count: { $sum: 1 } } }
    ]);
    
    // Monthly statistics for last 12 months
    const now = new Date();
    const monthlyStats = [];
    
    for (let i = 11; i >= 0; i--) {
      const startDate = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const endDate = new Date(now.getFullYear(), now.getMonth() - i + 1, 1);
      
      const count = await Emergency.countDocuments({
        user: userId,
        createdAt: { $gte: startDate, $lt: endDate }
      });
      
      monthlyStats.push({
        month: startDate.toLocaleString('default', { month: 'short', year: '2-digit' }),
        alerts: count,
        timestamp: startDate
      });
    }
    
    // Safe routes (routes with no danger signals)
    const safeRoutes = await Emergency.countDocuments({
      user: userId,
      dangerSignals: { $size: 0 }
    });
    
    // Dangerous locations (routes with danger signals)
    const dangerousLocations = await Emergency.aggregate([
      { $match: { user: req.user._id, dangerSignals: { $exists: true, $ne: [] } } },
      { $unwind: "$dangerSignals" },
      { $group: {
        _id: {
          lat: "$latestLocation.lat",
          lng: "$latestLocation.lng"
        },
        count: { $sum: 1 },
        signals: { $push: "$dangerSignals.label" }
      } },
      { $limit: 10 }
    ]);
    
    // Active vs ended emergencies
    const activeCount = await Emergency.countDocuments({ user: userId, status: "active" });
    const endedCount = await Emergency.countDocuments({ user: userId, status: "ended" });
    
    // Average emergency duration
    const avgDuration = await Emergency.aggregate([
      { $match: { user: req.user._id, endedAt: { $exists: true } } },
      { $project: {
        duration: {
          $divide: [
            { $subtract: ["$endedAt", "$startedAt"] },
            1000 * 60 // Convert to minutes
          ]
        }
      } },
      { $group: { _id: null, avgDuration: { $avg: "$duration" } } }
    ]);
    
    // Contacts notified count
    const totalContactsNotified = await Emergency.aggregate([
      { $match: { user: req.user._id } },
      { $group: { _id: null, totalNotifications: { $sum: { $size: "$notifiedContacts" } } } }
    ]);
    
    res.json({
      totalAlerts,
      activeAlerts: activeCount,
      endedAlerts: endedCount,
      alertsByType: alertsByType.map(item => ({
        type: item._id || "unknown",
        count: item.count
      })),
      safeRoutes,
      dangerousLocations: dangerousLocations.map(loc => ({
        lat: loc._id.lat,
        lng: loc._id.lng,
        incidentCount: loc.count,
        signals: [...new Set(loc.signals)]
      })),
      monthlyStats,
      avgEmergencyDurationMinutes: avgDuration[0]?.avgDuration || 0,
      totalContactsNotified: totalContactsNotified[0]?.totalNotifications || 0
    });
  } catch (error) {
    next(error);
  }
}

module.exports = { getAnalytics };
