async function nearbyPlaces(req, res) {
  const { lat, lng } = req.query;
  const baseLat = Number(lat) || 28.6139;
  const baseLng = Number(lng) || 77.209;

  res.json({
    places: [
      {
        name: "Nearest Police Help Desk",
        type: "Police",
        distance: "0.8 km",
        location: { lat: baseLat + 0.004, lng: baseLng - 0.002 }
      },
      {
        name: "City Emergency Hospital",
        type: "Hospital",
        distance: "1.4 km",
        location: { lat: baseLat - 0.006, lng: baseLng + 0.003 }
      },
      {
        name: "24x7 Women Helpline Center",
        type: "Emergency Service",
        distance: "2.1 km",
        location: { lat: baseLat + 0.01, lng: baseLng + 0.006 }
      }
    ]
  });
}

module.exports = { nearbyPlaces };
