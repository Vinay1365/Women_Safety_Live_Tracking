const Emergency = require("../models/Emergency");

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function toFiniteNumber(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function getTimeRisk(date = new Date()) {
  const hour = date.getHours();
  if (hour >= 22 || hour < 5) return 25;
  if (hour >= 19 && hour < 22) return 15;
  if (hour >= 5 && hour < 8) return 10;
  return 5;
}

function getLocationRisk(lat, lng) {
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return 15;
  const smallLat = Math.abs(lat % 0.1);
  const smallLng = Math.abs(lng % 0.1);
  if (smallLat < 0.02 && smallLng < 0.02) return 25;
  if (smallLat < 0.05 || smallLng < 0.05) return 18;
  return 10;
}

function getCrimeRisk(lat, lng) {
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return 15;
  const factor = Math.sin(lat * 3.1) + Math.cos(lng * 2.7);
  const score = Math.round((1 - Math.min(1, Math.max(-1, factor))) * 15);
  return clamp(score, 8, 25);
}

function getDangerLabel(score) {
  if (score >= 80) return "Low";
  if (score >= 60) return "Medium";
  if (score >= 40) return "High";
  return "Critical";
}

function getSafetyMessage(dangerLevel) {
  if (dangerLevel === "Low") {
    return "Safety Score looks good. Stay aware and keep trusted contacts updated.";
  }
  if (dangerLevel === "Medium") {
    return "Use caution. Check your route, stay in lit areas, and keep SOS ready.";
  }
  if (dangerLevel === "High") {
    return "Danger Level is high. Avoid isolated routes and contact someone you trust.";
  }
  return "Danger Level is critical. Move to a safer public place or alert emergency contacts.";
}

function getDisplayOutput(score, dangerLevel) {
  if (dangerLevel === "High" || dangerLevel === "Critical") {
    return `Danger Level = ${dangerLevel}`;
  }
  return `Safety Score = ${score}/100`;
}

function getRiskLevel(incidents) {
  if (incidents >= 5) return "high";
  if (incidents >= 2) return "moderate";
  return "safe";
}

function getRiskLabel(riskLevel) {
  if (riskLevel === "high") return "High Risk Area";
  if (riskLevel === "moderate") return "Moderate Risk Area";
  return "Safe Area";
}

function roundCoordinate(value) {
  return Math.round(value * 100) / 100;
}

async function safetyScore(req, res, next) {
  try {
    const lat = toFiniteNumber(req.query.lat);
    const lng = toFiniteNumber(req.query.lng);
    const timeRisk = getTimeRisk();
    const locationRisk = getLocationRisk(lat, lng);
    const crimeRisk = getCrimeRisk(lat, lng);

    const reports = await Emergency.countDocuments({
      user: req.user.id,
      createdAt: { $gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) }
    });

    const reportRisk = Math.min(25, reports * 5);
    const totalRisk = timeRisk + locationRisk + crimeRisk + reportRisk;
    const safetyScore = clamp(100 - totalRisk, 5, 100);
    const dangerLevel = getDangerLabel(safetyScore);

    res.json({
      safetyScore,
      dangerLevel,
      output: getDisplayOutput(safetyScore, dangerLevel),
      message: getSafetyMessage(dangerLevel),
      details: {
        timeRisk,
        locationRisk,
        crimeRisk,
        reportRisk,
        reports,
        totalRisk,
        basedOn: ["Time", "Location", "Crime data", "User reports"]
      }
    });
  } catch (error) {
    next(error);
  }
}

async function emergencyHeatmap(req, res, next) {
  try {
    const lat = toFiniteNumber(req.query.lat) ?? 28.6139;
    const lng = toFiniteNumber(req.query.lng) ?? 77.209;
    const since = new Date(Date.now() - 180 * 24 * 60 * 60 * 1000);

    const incidents = await Emergency.find({
      createdAt: { $gte: since },
      $or: [
        { "initialLocation.lat": { $exists: true }, "initialLocation.lng": { $exists: true } },
        { "latestLocation.lat": { $exists: true }, "latestLocation.lng": { $exists: true } }
      ]
    }).select("initialLocation latestLocation createdAt");

    const buckets = new Map();

    incidents.forEach((incident) => {
      const location = incident.latestLocation || incident.initialLocation;
      if (!Number.isFinite(location?.lat) || !Number.isFinite(location?.lng)) return;

      const bucketLat = roundCoordinate(location.lat);
      const bucketLng = roundCoordinate(location.lng);
      const key = `${bucketLat}:${bucketLng}`;
      const current = buckets.get(key) || {
        center: { lat: bucketLat, lng: bucketLng },
        incidents: 0,
        latestIncidentAt: incident.createdAt
      };

      current.incidents += 1;
      if (incident.createdAt > current.latestIncidentAt) current.latestIncidentAt = incident.createdAt;
      buckets.set(key, current);
    });

    const incidentAreas = Array.from(buckets.values()).map((area) => {
      const riskLevel = getRiskLevel(area.incidents);
      return {
        ...area,
        riskLevel,
        label: getRiskLabel(riskLevel),
        radiusMeters: riskLevel === "high" ? 900 : riskLevel === "moderate" ? 700 : 500
      };
    });

    const safeSeedAreas = [
      { center: { lat: lat + 0.018, lng: lng + 0.018 }, incidents: 0 },
      { center: { lat: lat - 0.018, lng: lng - 0.012 }, incidents: 0 },
      { center: { lat: lat + 0.012, lng: lng - 0.02 }, incidents: 0 }
    ].map((area) => ({
      ...area,
      riskLevel: "safe",
      label: "Safe Area",
      radiusMeters: 520,
      latestIncidentAt: null
    }));

    const areas = [...incidentAreas, ...safeSeedAreas]
      .sort((a, b) => b.incidents - a.incidents)
      .slice(0, 18);

    res.json({
      areas,
      summary: {
        safe: areas.filter((area) => area.riskLevel === "safe").length,
        moderate: areas.filter((area) => area.riskLevel === "moderate").length,
        high: areas.filter((area) => area.riskLevel === "high").length,
        incidentsAnalyzed: incidents.length,
        windowDays: 180
      }
    });
  } catch (error) {
    next(error);
  }
}

module.exports = { safetyScore, emergencyHeatmap };
