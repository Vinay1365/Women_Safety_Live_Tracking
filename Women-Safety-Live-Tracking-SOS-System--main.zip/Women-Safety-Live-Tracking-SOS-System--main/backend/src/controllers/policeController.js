const Emergency = require("../models/Emergency");

const userProjection = "name email phone homeAddress bloodGroup allergies emergencyDiseases medicalHistory medicalNotes";

async function activeAlerts(_req, res, next) {
  try {
    const alerts = await Emergency.find({ status: "active" })
      .populate("user", userProjection)
      .populate("notifiedContacts", "name relationship phone email priority")
      .sort({ startedAt: -1 })
      .limit(100);

    res.json({ alerts });
  } catch (error) {
    next(error);
  }
}

async function emergencyHistory(_req, res, next) {
  try {
    const emergencies = await Emergency.find({})
      .populate("user", userProjection)
      .sort({ startedAt: -1 })
      .limit(200);

    res.json({ emergencies });
  } catch (error) {
    next(error);
  }
}

async function emergencyDetails(req, res, next) {
  try {
    const emergency = await Emergency.findById(req.params.id)
      .populate("user", userProjection)
      .populate("notifiedContacts", "name relationship phone email priority");

    if (!emergency) return res.status(404).json({ message: "Emergency not found" });
    res.json({ emergency });
  } catch (error) {
    next(error);
  }
}

module.exports = { activeAlerts, emergencyHistory, emergencyDetails };
