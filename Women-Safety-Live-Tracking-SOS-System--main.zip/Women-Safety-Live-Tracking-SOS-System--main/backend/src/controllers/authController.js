const User = require("../models/User");
const signToken = require("../utils/token");
const devAuthStore = require("../utils/devAuthStore");
const mongoose = require("mongoose");

function isMongoReady() {
  return mongoose.connection.readyState === 1;
}

function sanitizeUser(user) {
  const doc = user.toObject();
  delete doc.password;
  return doc;
}

function getRoleForEmail(email) {
  const policeEmails = String(process.env.POLICE_EMAILS || "")
    .split(",")
    .map((value) => value.trim().toLowerCase())
    .filter(Boolean);

  return policeEmails.includes(String(email || "").toLowerCase()) ? "police" : "user";
}

function validateCaptcha(question, answer) {
  if (!question || !answer) return false;
  const expectedAnswers = {
    "Select the tiger image": "🐯",
    "Pick the red square": "🟥",
    "Choose the lock icon": "🔒",
    "Select the owl image": "🦉",
    "Choose the book icon": "📖"
  };

  const expected = expectedAnswers[question];
  return expected !== undefined && String(answer).trim() === expected;
}

async function register(req, res, next) {
  try {
    const { name, email, phone, password, captchaQuestion, captchaAnswer } = req.body;
    if (!validateCaptcha(captchaQuestion, captchaAnswer)) {
      return res.status(400).json({ message: "Captcha validation failed. Please solve the challenge correctly." });
    }

    if (!isMongoReady()) {
      const user = await devAuthStore.createUser({ name, email, phone, password, role: getRoleForEmail(email) });
      return res.status(201).json({ user, token: signToken(user.id) });
    }

    const exists = await User.findOne({ email });
    if (exists) return res.status(409).json({ message: "Email already registered" });

    const user = await User.create({ name, email, phone, password, role: getRoleForEmail(email) });
    res.status(201).json({ user: sanitizeUser(user), token: signToken(user.id) });
  } catch (error) {
    next(error);
  }
}

async function login(req, res, next) {
  try {
    const { email, password, captchaQuestion, captchaAnswer } = req.body;
    if (!validateCaptcha(captchaQuestion, captchaAnswer)) {
      return res.status(400).json({ message: "Captcha validation failed. Please solve the challenge correctly." });
    }

    if (!isMongoReady()) {
      const user = await devAuthStore.verifyUser(email, password);
      if (!user) return res.status(401).json({ message: "Invalid email or password" });
      return res.json({ user, token: signToken(user.id) });
    }

    const user = await User.findOne({ email }).select("+password");
    if (!user || !(await user.comparePassword(password))) {
      return res.status(401).json({ message: "Invalid email or password" });
    }

    const expectedRole = getRoleForEmail(user.email);
    if (user.role !== expectedRole) {
      user.role = expectedRole;
      await user.save();
    }

    res.json({ user: sanitizeUser(user), token: signToken(user.id) });
  } catch (error) {
    next(error);
  }
}

async function me(req, res) {
  res.json({ user: req.user });
}

module.exports = { register, login, me };
