async function emergencyAssistant(req, res) {
  const text = String(req.body.message || "").toLowerCase();
  let reply = "Stay calm. Move to a visible, well-lit area if possible. Keep live tracking active and call local emergency services.";

  if (text.includes("follow")) {
    reply = "Do not go home directly. Enter a crowded place, call emergency services, and keep your SOS live location on.";
  } else if (text.includes("taxi") || text.includes("cab") || text.includes("ride")) {
    reply = "Share trip details with contacts, sit near an exit, keep windows unlocked if safe, and trigger SOS if the route changes unexpectedly.";
  } else if (text.includes("medical") || text.includes("hospital")) {
    reply = "Call emergency medical services immediately. Share your live location and mention any known medical notes from your profile.";
  } else if (text.includes("rights") || text.includes("legal")) {
    reply = "You can ask for immediate help, contact a trusted person, record evidence if safe, and request a police report or medical assistance.";
  } else if (text.includes("self defense") || text.includes("self-defense") || text.includes("defend")) {
    reply = "Focus on escape first. Keep distance, use your voice to draw attention, aim for open public spaces, and trigger SOS as soon as you can.";
  } else if (text.includes("contact") || text.includes("emergency contacts")) {
    reply = "Alert your trusted contacts immediately, share your live location, and ask them to call local emergency services on your behalf if needed.";
  } else if (text.includes("nearest police") || text.includes("police station")) {
    reply = "Open the live map and nearby places list to find the closest police station. If you are in danger, call emergency services first and keep your SOS active.";
  }

  res.json({ reply });
}

module.exports = { emergencyAssistant };
