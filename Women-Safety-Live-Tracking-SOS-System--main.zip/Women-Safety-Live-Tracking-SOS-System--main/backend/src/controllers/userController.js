async function updateProfile(req, res, next) {
  try {
    const allowed = [
      "name",
      "phone",
      "avatarUrl",
      "homeAddress",
      "bloodGroup",
      "allergies",
      "emergencyDiseases",
      "medicalHistory",
      "medicalNotes",
      "preferences"
    ];

    allowed.forEach((field) => {
      if (req.body[field] !== undefined) req.user[field] = req.body[field];
    });

    await req.user.save();
    res.json({ user: req.user });
  } catch (error) {
    next(error);
  }
}

module.exports = { updateProfile };
