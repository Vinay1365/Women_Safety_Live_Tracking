const Contact = require("../models/Contact");
const Trip = require("../models/Trip");

function toPositiveNumber(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : fallback;
}

async function activeTrip(req, res, next) {
  try {
    const trip = await Trip.findOne({
      user: req.user.id,
      status: { $in: ["active", "overdue"] }
    }).sort({ createdAt: -1 });

    res.json({ trip });
  } catch (error) {
    next(error);
  }
}

async function startTrip(req, res, next) {
  try {
    const destination = String(req.body.destination || "").trim();
    if (!destination) return res.status(400).json({ message: "Destination is required" });

    const expectedMinutes = Math.min(toPositiveNumber(req.body.expectedMinutes, 30), 24 * 60);
    const expectedArrivalAt = new Date(Date.now() + expectedMinutes * 60 * 1000);

    await Trip.updateMany(
      { user: req.user.id, status: { $in: ["active", "overdue"] } },
      { status: "cancelled" }
    );

    const trip = await Trip.create({
      user: req.user.id,
      destination,
      expectedArrivalAt,
      startLocation: req.body.location,
      latestLocation: req.body.location
    });

    res.status(201).json({ trip });
  } catch (error) {
    next(error);
  }
}

async function updateTripLocation(req, res, next) {
  try {
    const location = { ...req.body.location, timestamp: new Date() };
    const trip = await Trip.findOneAndUpdate(
      { _id: req.params.id, user: req.user.id, status: { $in: ["active", "overdue"] } },
      { latestLocation: location },
      { new: true }
    );

    if (!trip) return res.status(404).json({ message: "Active trip not found" });
    res.json({ trip });
  } catch (error) {
    next(error);
  }
}

async function completeTrip(req, res, next) {
  try {
    const trip = await Trip.findOneAndUpdate(
      { _id: req.params.id, user: req.user.id, status: { $in: ["active", "overdue"] } },
      { status: "completed", completedAt: new Date(), latestLocation: req.body.location },
      { new: true }
    );

    if (!trip) return res.status(404).json({ message: "Active trip not found" });
    res.json({ trip });
  } catch (error) {
    next(error);
  }
}

async function cancelTrip(req, res, next) {
  try {
    const trip = await Trip.findOneAndUpdate(
      { _id: req.params.id, user: req.user.id, status: { $in: ["active", "overdue"] } },
      { status: "cancelled" },
      { new: true }
    );

    if (!trip) return res.status(404).json({ message: "Active trip not found" });
    res.json({ trip });
  } catch (error) {
    next(error);
  }
}

async function tripHistory(req, res, next) {
  try {
    const trips = await Trip.find({ user: req.user.id }).sort({ createdAt: -1 }).limit(50);
    res.json({ trips });
  } catch (error) {
    next(error);
  }
}

async function tripContacts(req, res, next) {
  try {
    const contacts = await Contact.find({ user: req.user.id }).sort({ priority: 1 });
    res.json({ contacts });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  activeTrip,
  startTrip,
  updateTripLocation,
  completeTrip,
  cancelTrip,
  tripHistory,
  tripContacts
};
