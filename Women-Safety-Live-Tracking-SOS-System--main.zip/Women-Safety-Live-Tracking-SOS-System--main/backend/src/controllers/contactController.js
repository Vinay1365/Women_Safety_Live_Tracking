const Contact = require("../models/Contact");

async function listContacts(req, res, next) {
  try {
    const contacts = await Contact.find({ user: req.user.id }).sort({ priority: 1, createdAt: -1 });
    res.json({ contacts });
  } catch (error) {
    next(error);
  }
}

async function createContact(req, res, next) {
  try {
    const contact = await Contact.create({ ...req.body, user: req.user.id });
    res.status(201).json({ contact });
  } catch (error) {
    next(error);
  }
}

async function updateContact(req, res, next) {
  try {
    const contact = await Contact.findOneAndUpdate(
      { _id: req.params.id, user: req.user.id },
      req.body,
      { new: true, runValidators: true }
    );
    if (!contact) return res.status(404).json({ message: "Contact not found" });
    res.json({ contact });
  } catch (error) {
    next(error);
  }
}

async function deleteContact(req, res, next) {
  try {
    const contact = await Contact.findOneAndDelete({ _id: req.params.id, user: req.user.id });
    if (!contact) return res.status(404).json({ message: "Contact not found" });
    res.json({ message: "Contact deleted" });
  } catch (error) {
    next(error);
  }
}

module.exports = { listContacts, createContact, updateContact, deleteContact };
