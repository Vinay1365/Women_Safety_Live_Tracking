const Contact = require("../models/Contact");
const Emergency = require("../models/Emergency");
const { notifyContacts, buildEmergencyMessage } = require("../utils/notifications");
const { uploadMediaToCloud } = require("../utils/cloudStorage");
const { emitEmergencyUpdate } = require("../sockets");

async function startEmergency(req, res, next) {
  try {
    const contacts = await Contact.find({ user: req.user.id }).sort({ priority: 1 });
    const emergency = await Emergency.create({
      user: req.user.id,
      triggerType: req.body.triggerType || "button",
      message: req.body.message || "Emergency SOS activated",
      initialLocation: req.body.location,
      latestLocation: req.body.location,
      route: req.body.location ? [req.body.location] : [],
      notifiedContacts: contacts.map((contact) => contact._id)
    });

    // Offline-SOS: notifications may rely on SMS only (no internet on client).
    // If SMS is enabled, Twilio will still require server-side internet.
    // However, GPS coordinates are embedded directly in the SMS body.
    // For best resilience, build message here and pass through.
    const emergencyMessage = buildEmergencyMessage(req.user, emergency);

    notifyContacts(req.user, contacts, emergency, emergencyMessage).catch((error) => {
      console.error("Notification failure:", error.message);
    });

    emitEmergencyUpdate(req.user.id, "emergency:start", emergency);
    res.status(201).json({ emergency, contactsNotified: contacts.length });
  } catch (error) {
    next(error);
  }
}

async function createEvidenceSession(req, res, next) {
  try {
    const emergency = await Emergency.create({
      user: req.user.id,
      triggerType: "manual",
      message: "Evidence recording session",
      status: "ended",
      startedAt: new Date(),
      endedAt: new Date()
    });

    res.status(201).json({ emergency });
  } catch (error) {
    next(error);
  }
}

async function updateLocation(req, res, next) {
  try {
    const location = { ...req.body.location, timestamp: new Date() };
    const emergency = await Emergency.findOneAndUpdate(
      { _id: req.params.id, user: req.user.id, status: "active" },
      { latestLocation: location, $push: { route: location } },
      { new: true }
    );

    if (!emergency) return res.status(404).json({ message: "Active emergency not found" });
    emitEmergencyUpdate(req.user.id, "emergency:location", { emergencyId: emergency.id, location });
    res.json({ emergency });
  } catch (error) {
    next(error);
  }
}

async function endEmergency(req, res, next) {
  try {
    const emergency = await Emergency.findOneAndUpdate(
      { _id: req.params.id, user: req.user.id, status: "active" },
      { status: "ended", endedAt: new Date() },
      { new: true }
    );

    if (!emergency) return res.status(404).json({ message: "Active emergency not found" });
    emitEmergencyUpdate(req.user.id, "emergency:end", emergency);
    res.json({ emergency });
  } catch (error) {
    next(error);
  }
}

async function history(req, res, next) {
  try {
    const emergencies = await Emergency.find({ user: req.user.id }).sort({ createdAt: -1 }).limit(50);
    res.json({ emergencies });
  } catch (error) {
    next(error);
  }
}

async function uploadMedia(req, res, next) {
  try {
    const emergency = await Emergency.findOne({ _id: req.params.id, user: req.user.id });
    if (!emergency) return res.status(404).json({ message: "Emergency not found" });

    const cloudFile = await uploadMediaToCloud(req.file);
    const media = {
      type: req.file.mimetype.startsWith("audio") ? "audio" : "video",
      originalName: req.file.originalname,
      size: req.file.size,
      ...cloudFile
    };

    emergency.media.push(media);
    await emergency.save();
    res.status(201).json({
      media,
      emergency,
      locker: {
        secured: true,
        provider: media.cloudProvider,
        message: media.cloudProvider === "local" ? "Evidence saved to local locker storage." : "Evidence uploaded to cloud locker."
      }
    });
  } catch (error) {
    next(error);
  }
}

async function analyzeDangerSignal(req, res, next) {
  try {
    const { decibels = 0, screamScore = 0 } = req.body;
    const confidence = Math.min(1, Number(decibels) / 110 * 0.4 + Number(screamScore) * 0.6);
    const danger = confidence > 0.72;
    res.json({
      danger,
      confidence,
      label: danger ? "High-risk sound pattern detected" : "No immediate danger detected"
    });
  } catch (error) {
    next(error);
  }
}

async function handlePanicAlert(req, res, next) {
  try {
    const { voiceStressLevel, detectionTime, reason } = req.body;
    const emergency = await Emergency.findOne({ _id: req.params.id, user: req.user.id });
    
    if (!emergency) {
      return res.status(404).json({ message: "Emergency not found" });
    }

    // Add danger signal for panic detection
    emergency.dangerSignals.push({
      label: `Panic Detected (Stress: ${(voiceStressLevel * 100).toFixed(0)}%)`,
      confidence: voiceStressLevel,
      createdAt: new Date()
    });

    await emergency.save();

    // Auto-notify all contacts if emergency is active
    if (emergency.status === "active") {
      const contacts = await Contact.find({ user: req.user.id }).sort({ priority: 1 });
      const User = require("../models/User");
      const user = await User.findById(req.user.id);
      
      const panicMessage = `🚨 PANIC DETECTED - Voice stress analysis indicates extreme distress (${(voiceStressLevel * 100).toFixed(0)}%). ${emergency.message}. Location: https://maps.google.com/?q=${emergency.latestLocation?.lat},${emergency.latestLocation?.lng}`;

      notifyContacts(user, contacts, emergency, panicMessage).catch((error) => {
        console.error("Panic notification failure:", error.message);
      });

      emitEmergencyUpdate(req.user.id, "emergency:panic-detected", {
        emergencyId: emergency._id,
        stressLevel: voiceStressLevel,
        timestamp: detectionTime
      });
    }

    res.json({ 
      emergency, 
      message: "Panic alert recorded and emergency contacts notified" 
    });
  } catch (error) {
    next(error);
  }
}

module.exports = { startEmergency, createEvidenceSession, updateLocation, endEmergency, history, uploadMedia, analyzeDangerSignal, handlePanicAlert };
