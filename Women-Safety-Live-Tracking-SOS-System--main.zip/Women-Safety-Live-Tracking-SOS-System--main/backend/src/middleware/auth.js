const jwt = require("jsonwebtoken");
const User = require("../models/User");
const devAuthStore = require("../utils/devAuthStore");
const mongoose = require("mongoose");

async function protect(req, res, next) {
  try {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ") ? header.slice(7) : null;

    if (!token) {
      return res.status(401).json({ message: "Authentication required" });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = mongoose.connection.readyState === 1
      ? await User.findById(decoded.id)
      : devAuthStore.findUserById(decoded.id);

    if (!req.user) {
      return res.status(401).json({ message: "User no longer exists" });
    }

    next();
  } catch (error) {
    res.status(401).json({ message: "Invalid or expired token" });
  }
}

function requirePolice(req, res, next) {
  if (req.user?.role !== "police") {
    return res.status(403).json({ message: "Police portal access required" });
  }

  next();
}

module.exports = { protect, requirePolice };
