const mongoose = require("mongoose");

async function connectDB() {
  const primaryUri = process.env.MONGODB_URI;
  const fallbackUri =
    process.env.MONGODB_FALLBACK_URI ||
    (process.env.NODE_ENV !== "production" ? "mongodb://127.0.0.1:27017/womenSafety" : "");

  if (!primaryUri && !fallbackUri) {
    throw new Error("MONGODB_URI is missing in .env file");
  }

  mongoose.set("strictQuery", true);

  try {
    await mongoose.connect(primaryUri || fallbackUri, {
      serverSelectionTimeoutMS: 5000
    });
  } catch (primaryError) {
    if (!primaryUri || !fallbackUri || primaryUri === fallbackUri) {
      throw primaryError;
    }

    console.warn(`MongoDB primary connection failed: ${primaryError.message}`);
    console.warn("Trying the local development database...");
    await mongoose.disconnect().catch(() => {});
    await mongoose.connect(fallbackUri, {
      serverSelectionTimeoutMS: 5000
    });
  }

  return mongoose.connection;
}

module.exports = connectDB;
