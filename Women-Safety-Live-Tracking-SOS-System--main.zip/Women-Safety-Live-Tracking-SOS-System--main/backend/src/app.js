const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");

const authRoutes = require("./routes/authRoutes");
const userRoutes = require("./routes/userRoutes");
const contactRoutes = require("./routes/contactRoutes");
const emergencyRoutes = require("./routes/emergencyRoutes");
const analyticsRoutes = require("./routes/analyticsRoutes");
const nearbyRoutes = require("./routes/nearbyRoutes");
const chatbotRoutes = require("./routes/chatbotRoutes");
const safetyRoutes = require("./routes/safetyRoutes");
const tripRoutes = require("./routes/tripRoutes");
const policeRoutes = require("./routes/policeRoutes");
const { notFound, errorHandler } = require("./middleware/errorHandler");

const app = express();
const allowedOrigins = new Set([
  process.env.CLIENT_URL || "http://localhost:5173",
  "http://localhost:5173",
  "http://127.0.0.1:5173"
]);

app.use(helmet({ crossOriginResourcePolicy: { policy: "cross-origin" } }));
app.use(
  cors({
    origin(origin, callback) {
      if (!origin || allowedOrigins.has(origin)) return callback(null, true);
      return callback(new Error(`Origin not allowed by CORS: ${origin}`));
    },
    credentials: true
  })
);
app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));
app.use("/uploads", express.static(path.join(__dirname, "..", "uploads")));

app.use(
  "/api",
  rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 500,
    standardHeaders: true,
    legacyHeaders: false
  })
);

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", service: "women-safety-api" });
});

app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);
app.use("/api/contacts", contactRoutes);
app.use("/api/emergencies", emergencyRoutes);
app.use("/api/analytics", analyticsRoutes);
app.use("/api/nearby", nearbyRoutes);
app.use("/api/chatbot", chatbotRoutes);
app.use("/api/safety", safetyRoutes);
app.use("/api/trips", tripRoutes);
app.use("/api/police", policeRoutes);

app.use(notFound);
app.use(errorHandler);

module.exports = app;
