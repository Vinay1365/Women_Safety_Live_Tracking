const http = require("http");
const dotenv = require("dotenv");

dotenv.config();

const app = require("./app");
const connectDB = require("./config/db");
const { initSocket } = require("./sockets");
const { startTripMonitor } = require("./utils/tripMonitor");

const PORT = process.env.PORT || 5000;
const DB_STARTUP_TIMEOUT_MS = 8000;

function connectDBWithTimeout() {
  let timedOut = false;
  const dbPromise = connectDB().catch((error) => {
    if (timedOut) {
      console.warn(`MongoDB background connection failed: ${error.message}`);
      return null;
    }

    throw error;
  });

  return Promise.race([
    dbPromise,
    new Promise((_, reject) => {
      setTimeout(() => {
        timedOut = true;
        reject(new Error("MongoDB connection timed out during startup"));
      }, DB_STARTUP_TIMEOUT_MS);
    })
  ]);
}

async function startServer() {
  let databaseReady = false;

  try {
    const connection = await connectDBWithTimeout();
    databaseReady = true;
    console.log(`MongoDB connected: ${connection.host}/${connection.name}`);
  } catch (error) {
    if (process.env.NODE_ENV === "production") {
      console.error("Server startup failed:");
      console.error(error);
      process.exit(1);
    }

    console.warn("MongoDB unavailable. Starting with in-memory development auth store.");
    console.warn(error.message);
  }

  const server = http.createServer(app);
  initSocket(server);

  if (databaseReady) {
    startTripMonitor();
  }

  server.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
  });
}

startServer();
