const mongoose = require("mongoose");

const locationSchema = new mongoose.Schema(
  {
    lat: Number,
    lng: Number,
    accuracy: Number,
    speed: Number,
    heading: Number,
    timestamp: { type: Date, default: Date.now }
  },
  { _id: false }
);

const tripSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    destination: { type: String, required: true, trim: true },
    status: {
      type: String,
      enum: ["active", "completed", "overdue", "cancelled"],
      default: "active"
    },
    startedAt: { type: Date, default: Date.now },
    expectedArrivalAt: { type: Date, required: true },
    completedAt: Date,
    alertedAt: Date,
    alertSent: { type: Boolean, default: false },
    startLocation: locationSchema,
    latestLocation: locationSchema,
    notifiedContacts: [{ type: mongoose.Schema.Types.ObjectId, ref: "Contact" }]
  },
  { timestamps: true }
);

module.exports = mongoose.model("Trip", tripSchema);
