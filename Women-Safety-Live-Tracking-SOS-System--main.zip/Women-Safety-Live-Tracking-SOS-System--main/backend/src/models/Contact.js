const mongoose = require("mongoose");

const contactSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    name: { type: String, required: true, trim: true },
    relationship: {
      type: String,
      enum: ["Family", "Friend", "Police", "Hospital", "Emergency Service", "Other"],
      default: "Other"
    },
    phone: { type: String, trim: true },
    email: { type: String, lowercase: true, trim: true },
    priority: { type: Number, default: 1 },
    notifyBySms: { type: Boolean, default: true },
    notifyByEmail: { type: Boolean, default: true }
  },
  { timestamps: true }
);

module.exports = mongoose.model("Contact", contactSchema);
