const mongoose = require("mongoose");

const locationSchema = new mongoose.Schema(
  {
    lat: Number,
    lng: Number,
    accuracy: Number,
    speed: Number,
    heading: Number,
    timestamp: { type: Date, default: Date.now }
  },
  { _id: false }
);

const emergencySchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    status: { type: String, enum: ["active", "ended"], default: "active" },
    triggerType: {
      type: String,
      enum: ["button", "voice", "fake-call", "sound-analysis", "manual"],
      default: "button"
    },
    message: String,
    startedAt: { type: Date, default: Date.now },
    endedAt: Date,
    initialLocation: locationSchema,
    latestLocation: locationSchema,
    route: [locationSchema],
    notifiedContacts: [{ type: mongoose.Schema.Types.ObjectId, ref: "Contact" }],
    media: [
      {
        type: { type: String, enum: ["audio", "video"] },
        url: String,
        cloudProvider: { type: String, default: "local" },
        publicId: String,
        originalName: String,
        size: Number,
        createdAt: { type: Date, default: Date.now }
      }
    ],
    dangerSignals: [
      {
        label: String,
        confidence: Number,
        createdAt: { type: Date, default: Date.now }
      }
    ]
  },
  { timestamps: true }
);

module.exports = mongoose.model("Emergency", emergencySchema);
