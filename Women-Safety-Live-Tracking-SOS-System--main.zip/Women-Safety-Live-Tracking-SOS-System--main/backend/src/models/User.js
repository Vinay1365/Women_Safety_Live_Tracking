const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const validator = require("validator");

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 80 },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      validate: [validator.isEmail, "Please provide a valid email"]
    },
    phone: { type: String, trim: true },
    role: { type: String, enum: ["user", "police"], default: "user" },
    password: { type: String, required: true, minlength: 6, select: false },
    avatarUrl: String,
    homeAddress: String,
    bloodGroup: String,
    allergies: String,
    emergencyDiseases: String,
    medicalHistory: String,
    medicalNotes: String,
    preferences: {
      theme: { type: String, enum: ["light", "dark"], default: "light" },
      voiceSosPhrase: { type: String, default: "help me" },
      autoRecordAudio: { type: Boolean, default: true },
      autoRecordVideo: { type: Boolean, default: true }
    }
  },
  { timestamps: true }
);

userSchema.pre("save", async function hashPassword(next) {
  if (!this.isModified("password")) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

userSchema.methods.comparePassword = function comparePassword(candidate) {
  return bcrypt.compare(candidate, this.password);
};

module.exports = mongoose.model("User", userSchema);
