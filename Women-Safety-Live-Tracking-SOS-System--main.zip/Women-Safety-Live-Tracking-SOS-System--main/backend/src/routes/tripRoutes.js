const router = require("express").Router();
const { protect } = require("../middleware/auth");
const {
  activeTrip,
  startTrip,
  updateTripLocation,
  completeTrip,
  cancelTrip,
  tripHistory,
  tripContacts
} = require("../controllers/tripController");

router.use(protect);
router.get("/active", activeTrip);
router.get("/history", tripHistory);
router.get("/contacts", tripContacts);
router.post("/start", startTrip);
router.patch("/:id/location", updateTripLocation);
router.patch("/:id/complete", completeTrip);
router.patch("/:id/cancel", cancelTrip);

module.exports = router;
