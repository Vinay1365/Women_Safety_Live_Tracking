const router = require("express").Router();
const { protect } = require("../middleware/auth");
const { emergencyAssistant } = require("../controllers/chatbotController");

router.post("/", protect, emergencyAssistant);

module.exports = router;
