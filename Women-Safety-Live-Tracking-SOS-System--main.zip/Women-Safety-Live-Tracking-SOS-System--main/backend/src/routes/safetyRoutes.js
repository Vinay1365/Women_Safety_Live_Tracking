const router = require("express").Router();
const { protect } = require("../middleware/auth");
const { safetyScore, emergencyHeatmap } = require("../controllers/safetyController");

router.use(protect);
router.get("/score", safetyScore);
router.get("/heatmap", emergencyHeatmap);

module.exports = router;
