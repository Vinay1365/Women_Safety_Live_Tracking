const router = require("express").Router();
const { protect } = require("../middleware/auth");
const { nearbyPlaces } = require("../controllers/nearbyController");

router.get("/places", protect, nearbyPlaces);

module.exports = router;
