const router = require("express").Router();
const { protect } = require("../middleware/auth");
const { getAnalytics } = require("../controllers/analyticsController");

router.use(protect);
router.get("/", getAnalytics);

module.exports = router;
