const router = require("express").Router();
const { protect, requirePolice } = require("../middleware/auth");
const { activeAlerts, emergencyHistory, emergencyDetails } = require("../controllers/policeController");

router.use(protect, requirePolice);
router.get("/alerts/active", activeAlerts);
router.get("/emergencies/history", emergencyHistory);
router.get("/emergencies/:id", emergencyDetails);

module.exports = router;
