const router = require("express").Router();
const { protect } = require("../middleware/auth");
const upload = require("../middleware/upload");
const {
  startEmergency,
  createEvidenceSession,
  updateLocation,
  endEmergency,
  history,
  uploadMedia,
  analyzeDangerSignal,
  handlePanicAlert
} = require("../controllers/emergencyController");

router.use(protect);
router.get("/history", history);
router.post("/start", startEmergency);
router.post("/evidence-session", createEvidenceSession);
router.patch("/:id/location", updateLocation);
router.patch("/:id/end", endEmergency);
router.post("/:id/media", upload.single("media"), uploadMedia);
router.post("/:id/panic-alert", handlePanicAlert);
router.post("/analyze-sound", analyzeDangerSignal);

module.exports = router;
