const router = require("express").Router();
const { protect } = require("../middleware/auth");
const { listContacts, createContact, updateContact, deleteContact } = require("../controllers/contactController");

router.use(protect);
router.route("/").get(listContacts).post(createContact);
router.route("/:id").put(updateContact).delete(deleteContact);

module.exports = router;
