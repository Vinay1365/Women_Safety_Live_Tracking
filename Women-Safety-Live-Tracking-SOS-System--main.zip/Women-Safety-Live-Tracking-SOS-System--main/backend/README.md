# Women Safety Backend

Express + MongoDB API for authentication, emergency contacts, SOS sessions, live GPS tracking, media uploads, alerts, and Socket.IO real-time updates.

## Setup

```bash
cd backend
cp .env.example .env
npm install
npm run dev
```

MongoDB must be running locally or `MONGODB_URI` must point to a cloud MongoDB instance.
